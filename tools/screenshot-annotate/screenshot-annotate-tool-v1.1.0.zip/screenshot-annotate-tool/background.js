// background.js — service worker
// コマンド / ポップアップからのキャプチャ要求を処理する司令塔。

const RESTRICTED = /^(chrome|edge|brave|about|chrome-extension|devtools|view-source|https:\/\/chrome\.google\.com\/webstore|https:\/\/chromewebstore\.google\.com)/i;

// 動作記録（直近30件）。うまく動かない時の原因調べ用
let logChain = Promise.resolve();
function debugLog(event, detail) {
  // 書き込みが重なって記録が消えないよう、順番に書く
  logChain = logChain.then(async () => {
    try {
      const { debugLog: list = [] } = await chrome.storage.local.get("debugLog");
      list.push({ t: new Date().toISOString(), event, detail: String(detail || "").slice(0, 300) });
      await chrome.storage.local.set({ debugLog: list.slice(-30) });
    } catch (e) {}
  });
  return logChain;
}

// アイコンに印を出す（通知がオフでも気づけるように）
function badge(text, color, title) {
  try {
    chrome.action.setBadgeText({ text });
    chrome.action.setBadgeBackgroundColor({ color });
    if (title) chrome.action.setTitle({ title });
    setTimeout(() => {
      chrome.action.setBadgeText({ text: "" });
      chrome.action.setTitle({ title: "スクショ + 注釈ツール" });
    }, 6000);
  } catch (e) {}
}

function notify(message, title = "スクショツール") {
  debugLog("error", message);
  badge("!", "#d93025", message);
  try {
    chrome.notifications.create({
      type: "basic",
      iconUrl: "icons/icon128.png",
      title,
      message,
    });
  } catch (e) {
    console.warn("notify失敗:", e, message);
  }
}

function canInject(tab) {
  return tab && tab.url && !RESTRICTED.test(tab.url);
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  return tab;
}

function pageMeta(tab) {
  return { title: (tab && tab.title) || "", url: (tab && tab.url) || "" };
}

// 編集ページを開く（画像は storage.local の一意キー経由で受け渡し）
async function openEditor(pending, srcTab) {
  const id = Date.now() + "_" + Math.random().toString(36).slice(2, 7);
  await chrome.storage.local.set({ ["pending_" + id]: pending });
  await openEditorTab(id, srcTab);
}

async function openEditorTab(id, srcTab) {
  const props = { url: chrome.runtime.getURL("editor/editor.html?p=" + id) };
  if (srcTab) {
    props.windowId = srcTab.windowId;
    props.index = srcTab.index + 1;
    props.openerTabId = srcTab.id;
  }
  try {
    await chrome.tabs.create(props);
  } catch (e) {
    await chrome.tabs.create({ url: props.url });
  }
}

function guard(tab, what) {
  if (!canInject(tab)) {
    notify(`このページでは${what}できません（chrome:// やウェブストア等）。`);
    return false;
  }
  return true;
}

// ---- 表示されている画面 ----
async function captureVisible(tab) {
  if (!guard(tab, "キャプチャ")) return;
  try {
    const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" });
    await openEditor({ image: dataUrl, ...pageMeta(tab) }, tab);
  } catch (e) {
    notify("キャプチャに失敗しました: " + e.message);
  }
}

// ---- 範囲選択 ----
// 先に画面を撮り、その静止画の上で範囲を選ばせる（ホバーメニュー等も撮れる）
async function captureArea(tab) {
  if (!guard(tab, "範囲選択")) return;
  try {
    const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" });
    await chrome.storage.local.set({ ["areaFull_" + tab.id]: dataUrl });
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: (img) => {
        window.__scshot_frozen = img;
      },
      args: [dataUrl],
    });
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content/selection.js"],
    });
  } catch (e) {
    notify("範囲選択の起動に失敗しました: " + e.message);
  }
}

// ---- ページ全体 ----
async function captureFullPage(tab, region) {
  if (!guard(tab, "ページ全体キャプチャ")) return;
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: (r) => {
        window.__scshot_region = r;
      },
      args: [region || null],
    });
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content/fullpage.js"],
    });
  } catch (e) {
    notify("ページ全体キャプチャの起動に失敗しました: " + e.message);
  }
}

// ---- 要素クリック ----
async function captureElement(tab) {
  if (!guard(tab, "要素の撮影")) return;
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content/element.js"],
    });
  } catch (e) {
    notify("要素の撮影を起動できませんでした: " + e.message);
  }
}

// ---- 3秒タイマー → 範囲選択 ----
async function captureDelayed(tab) {
  if (!guard(tab, "タイマー撮影")) return;
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content/countdown.js"],
    });
  } catch (e) {
    notify("タイマー撮影を起動できませんでした: " + e.message);
  }
}

// ---- 前回と同じ範囲 ----
async function captureRepeat(tab) {
  if (!guard(tab, "キャプチャ")) return;
  const { lastArea } = await chrome.storage.local.get("lastArea");
  if (!lastArea) {
    notify("まだ範囲の記録がありません。先に「範囲を選択」で1回撮ってください。");
    return;
  }
  try {
    const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" });
    await openEditor({ image: dataUrl, crop: lastArea, ...pageMeta(tab) }, tab);
  } catch (e) {
    notify("キャプチャに失敗しました: " + e.message);
  }
}

const MODES = {
  area: captureArea,
  visible: captureVisible,
  fullpage: (tab) => captureFullPage(tab, null),
  element: captureElement,
  delayed: captureDelayed,
  repeat: captureRepeat,
};

// ---- ショートカット ----
chrome.commands.onCommand.addListener(async (command, tab) => {
  debugLog("command", command + " " + (tab && tab.url ? tab.url.slice(0, 80) : "(no tab)"));
  const mode = command.replace(/^capture-/, "");
  const fn = MODES[mode];
  if (!fn) return;
  fn(tab && tab.url ? tab : await getActiveTab());
});

// ---- メッセージ（content / popup から）----
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // 範囲選択の完了：rect(CSS px)とdprを受け取り、撮影済み画像をcrop指定付きで編集へ
  if (msg.type === "AREA_DONE") {
    (async () => {
      const tab = sender.tab;
      const key = "areaFull_" + tab.id;
      const stored = await chrome.storage.local.get(key);
      const fullImage = stored[key];
      await chrome.storage.local.remove(key);
      if (!fullImage) {
        notify("撮影画像が見つかりませんでした。もう一度お試しください。");
        return;
      }
      await chrome.storage.local.set({ lastArea: msg.rect });
      await openEditor({ image: fullImage, crop: msg.rect, ...pageMeta(tab) }, tab);
    })();
    return false;
  }

  if (msg.type === "AREA_CANCEL") {
    chrome.storage.local.remove("areaFull_" + sender.tab.id);
    return false;
  }

  // 要素（画面内に収まる）：要素の枠を消した後の画面を撮って切り抜く
  if (msg.type === "ELEMENT_DONE") {
    (async () => {
      const tab = sender.tab;
      try {
        const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" });
        await chrome.storage.local.set({ lastArea: msg.rect });
        await openEditor({ image: dataUrl, crop: msg.rect, ...pageMeta(tab) }, tab);
      } catch (e) {
        notify("キャプチャに失敗しました: " + e.message);
      }
    })();
    return false;
  }

  // 要素（画面より大きい）：その範囲だけスクロール撮影
  if (msg.type === "ELEMENT_FULL") {
    captureFullPage(sender.tab, msg.region);
    return false;
  }

  if (msg.type === "COUNTDOWN_DONE") {
    captureArea(sender.tab);
    return false;
  }

  // 全画面キャプチャ中のタイル撮影要求
  if (msg.type === "CAPTURE_TILE") {
    chrome.tabs
      .captureVisibleTab(sender.tab.windowId, { format: "png" })
      .then((dataUrl) => sendResponse({ dataUrl }))
      .catch((e) => sendResponse({ error: e.message }));
    return true; // 非同期応答
  }

  // 全画面キャプチャ完了（画像は content が storage.local に書き込み済み）
  if (msg.type === "FULLPAGE_DONE") {
    openEditorTab(msg.id, sender.tab);
    return false;
  }

  if (msg.type === "FULLPAGE_ERROR") {
    notify("ページ全体キャプチャに失敗: " + (msg.message || ""));
    return false;
  }

  // ポップアップからの起動
  if (msg.type === "POPUP_CAPTURE") {
    debugLog("popup", msg.mode);
    (async () => {
      const fn = MODES[msg.mode];
      if (fn) await fn(await getActiveTab());
    })();
    return false;
  }
});

chrome.runtime.onInstalled.addListener((d) => debugLog("installed", d.reason + " v" + chrome.runtime.getManifest().version));
