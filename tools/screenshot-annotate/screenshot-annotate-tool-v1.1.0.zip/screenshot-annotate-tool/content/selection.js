// content/selection.js — 範囲選択オーバーレイ
// 画面は撮影済み。撮った静止画を全面に敷き、その上で矩形を選ばせる。
// CSSピクセルのrect + dpr を background へ返す。
(() => {
  const OVERLAY_ID = "__scshot_overlay__";
  const old = document.getElementById(OVERLAY_ID);
  if (old) old.remove();

  const frozen = window.__scshot_frozen || null;
  window.__scshot_frozen = null;

  const dpr = window.devicePixelRatio || 1;
  const vw = window.innerWidth;
  const vh = window.innerHeight;

  const overlay = document.createElement("div");
  overlay.id = OVERLAY_ID;
  Object.assign(overlay.style, {
    position: "fixed",
    left: "0",
    top: "0",
    width: vw + "px",
    height: vh + "px",
    zIndex: "2147483647",
    cursor: "crosshair",
    userSelect: "none",
    margin: "0",
    padding: "0",
  });
  if (frozen) {
    overlay.style.backgroundImage = `url("${frozen}")`;
    overlay.style.backgroundSize = `${vw}px ${vh}px`;
    overlay.style.backgroundRepeat = "no-repeat";
  }

  // ドラッグ前の全面の暗さ
  const dim = document.createElement("div");
  Object.assign(dim.style, {
    position: "absolute",
    inset: "0",
    background: "rgba(0,0,0,0.30)",
    pointerEvents: "none",
  });

  // 選択中の矩形（外側を boxShadow で暗くする）
  const box = document.createElement("div");
  Object.assign(box.style, {
    position: "fixed",
    border: "2px dashed #22a565",
    background: "transparent",
    boxShadow: "0 0 0 100vmax rgba(0,0,0,0.30)",
    display: "none",
    pointerEvents: "none",
  });

  // 十字ガイド（ドラッグ前）
  const guideX = document.createElement("div");
  const guideY = document.createElement("div");
  for (const g of [guideX, guideY]) {
    Object.assign(g.style, {
      position: "fixed",
      background: "rgba(255,255,255,0.75)",
      boxShadow: "0 0 0 0.5px rgba(0,0,0,0.5)",
      pointerEvents: "none",
      display: "none",
    });
  }
  Object.assign(guideX.style, { left: "0", width: "100vw", height: "1px" });
  Object.assign(guideY.style, { top: "0", height: "100vh", width: "1px" });

  const sizeLabel = document.createElement("div");
  Object.assign(sizeLabel.style, {
    position: "fixed",
    padding: "2px 6px",
    font: "12px/1.4 -apple-system, sans-serif",
    color: "#fff",
    background: "#22a565",
    borderRadius: "4px",
    display: "none",
    pointerEvents: "none",
    whiteSpace: "nowrap",
  });

  const hint = document.createElement("div");
  hint.textContent = "ドラッグで範囲を選択　/　Enterで画面全体　/　Escでキャンセル";
  Object.assign(hint.style, {
    position: "fixed",
    left: "50%",
    top: "16px",
    transform: "translateX(-50%)",
    padding: "6px 12px",
    font: "13px/1.4 -apple-system, sans-serif",
    color: "#fff",
    background: "rgba(0,0,0,0.7)",
    borderRadius: "6px",
    pointerEvents: "none",
    whiteSpace: "nowrap",
  });

  overlay.append(dim, guideX, guideY, box, sizeLabel, hint);
  document.documentElement.appendChild(overlay);

  let startX = 0,
    startY = 0,
    dragging = false;

  const clamp = (v, min, max) => Math.max(min, Math.min(max, v));

  function cleanup() {
    overlay.remove();
    window.removeEventListener("keydown", onKey, true);
  }

  function cancel() {
    cleanup();
    chrome.runtime.sendMessage({ type: "AREA_CANCEL" });
  }

  function done(rect) {
    cleanup();
    chrome.runtime.sendMessage({ type: "AREA_DONE", rect: { ...rect, dpr, vw } });
  }

  function onKey(e) {
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation();
      cancel();
    } else if (e.key === "Enter" && !dragging) {
      e.preventDefault();
      e.stopPropagation();
      done({ x: 0, y: 0, w: vw, h: vh });
    }
  }

  overlay.addEventListener("mousedown", (e) => {
    if (e.button !== 0) return;
    dragging = true;
    startX = e.clientX;
    startY = e.clientY;
    box.style.display = "block";
    sizeLabel.style.display = "block";
    guideX.style.display = guideY.style.display = "none";
    dim.style.display = "none"; // 以降は box の影で暗さを表現
  });

  overlay.addEventListener("mousemove", (e) => {
    if (!dragging) {
      guideX.style.display = guideY.style.display = "block";
      guideX.style.top = e.clientY + "px";
      guideY.style.left = e.clientX + "px";
      return;
    }
    const x = clamp(e.clientX, 0, vw);
    const y = clamp(e.clientY, 0, vh);
    const left = Math.min(startX, x);
    const top = Math.min(startY, y);
    const w = Math.abs(x - startX);
    const h = Math.abs(y - startY);
    box.style.left = left + "px";
    box.style.top = top + "px";
    box.style.width = w + "px";
    box.style.height = h + "px";
    sizeLabel.textContent = `${Math.round(w * dpr)} × ${Math.round(h * dpr)} px`;
    let ly = top - 24;
    if (ly < 4) ly = top + 4;
    sizeLabel.style.left = left + "px";
    sizeLabel.style.top = ly + "px";
  });

  overlay.addEventListener("mouseup", (e) => {
    if (!dragging) return;
    dragging = false;
    const x = clamp(e.clientX, 0, vw);
    const y = clamp(e.clientY, 0, vh);
    const left = Math.min(startX, x);
    const top = Math.min(startY, y);
    const w = Math.abs(x - startX);
    const h = Math.abs(y - startY);
    if (w < 4 || h < 4) {
      cancel(); // 小さすぎる選択はキャンセル扱い
      return;
    }
    done({ x: left, y: top, w, h });
  });

  window.addEventListener("keydown", onKey, true);
})();
