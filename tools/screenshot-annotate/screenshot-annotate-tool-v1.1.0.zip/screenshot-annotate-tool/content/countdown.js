// content/countdown.js — 3秒数えてから範囲選択へ（ホバーメニュー等を開いたまま撮る用）
(() => {
  if (window.__scshot_countdown_running) return;
  window.__scshot_countdown_running = true;

  const SECONDS = 3;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const frame = () => new Promise((r) => requestAnimationFrame(() => r()));

  const badge = document.createElement("div");
  Object.assign(badge.style, {
    position: "fixed",
    right: "24px",
    bottom: "24px",
    width: "64px",
    height: "64px",
    borderRadius: "50%",
    background: "rgba(0,0,0,0.75)",
    color: "#fff",
    font: "700 30px/64px -apple-system, sans-serif",
    textAlign: "center",
    zIndex: "2147483647",
    pointerEvents: "none",
    boxShadow: "0 4px 18px rgba(0,0,0,0.35)",
  });
  document.documentElement.appendChild(badge);

  let cancelled = false;
  function onKey(e) {
    if (e.key === "Escape") cancelled = true;
  }
  window.addEventListener("keydown", onKey, true);

  (async () => {
    for (let n = SECONDS; n >= 1 && !cancelled; n--) {
      badge.textContent = String(n);
      await sleep(1000);
    }
    badge.remove();
    window.removeEventListener("keydown", onKey, true);
    window.__scshot_countdown_running = false;
    if (cancelled) return;
    // バッジが消えた画面を撮らせる
    await frame();
    await frame();
    await sleep(40);
    chrome.runtime.sendMessage({ type: "COUNTDOWN_DONE" });
  })();
})();
