// content/element.js — カーソルを合わせた要素をクリックで撮影
// ↑ で親要素へ広げる / ↓ で戻す / Enter・クリックで決定 / Esc でやめる
(() => {
  if (window.__scshot_element_running) return;
  window.__scshot_element_running = true;

  const Z = "2147483647";
  const dpr = window.devicePixelRatio || 1;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const frame = () => new Promise((r) => requestAnimationFrame(() => r()));

  const hl = document.createElement("div");
  Object.assign(hl.style, {
    position: "fixed",
    zIndex: Z,
    pointerEvents: "none",
    border: "2px solid #22a565",
    background: "rgba(34,165,101,0.12)",
    borderRadius: "2px",
    display: "none",
    boxSizing: "border-box",
  });
  const label = document.createElement("div");
  Object.assign(label.style, {
    position: "fixed",
    zIndex: Z,
    pointerEvents: "none",
    padding: "2px 6px",
    font: "12px/1.4 -apple-system, sans-serif",
    color: "#fff",
    background: "#22a565",
    borderRadius: "4px",
    whiteSpace: "nowrap",
    display: "none",
  });
  const hint = document.createElement("div");
  hint.textContent = "クリックで撮影　/　↑で外側に広げる・↓で戻す　/　Escでやめる";
  Object.assign(hint.style, {
    position: "fixed",
    zIndex: Z,
    pointerEvents: "none",
    left: "50%",
    top: "16px",
    transform: "translateX(-50%)",
    padding: "6px 12px",
    font: "13px/1.4 -apple-system, sans-serif",
    color: "#fff",
    background: "rgba(0,0,0,0.75)",
    borderRadius: "6px",
    whiteSpace: "nowrap",
  });
  document.documentElement.append(hl, label, hint);

  let cur = null;
  let stack = [];
  let finished = false;

  function draw() {
    if (!cur) return;
    const r = cur.getBoundingClientRect();
    const vw = document.documentElement.clientWidth;
    const vh = window.innerHeight;
    const left = Math.max(0, r.left);
    const top = Math.max(0, r.top);
    const right = Math.min(vw, r.right);
    const bottom = Math.min(vh, r.bottom);
    Object.assign(hl.style, {
      display: "block",
      left: left + "px",
      top: top + "px",
      width: Math.max(0, right - left) + "px",
      height: Math.max(0, bottom - top) + "px",
    });
    const tag = cur.tagName.toLowerCase();
    label.textContent = `${tag}　${Math.round(r.width * dpr)} × ${Math.round(r.height * dpr)} px`;
    label.style.display = "block";
    label.style.left = left + "px";
    label.style.top = (top - 24 < 4 ? top + 4 : top - 24) + "px";
  }

  function onMove(e) {
    const el = document.elementFromPoint(e.clientX, e.clientY);
    if (!el || el === cur || el === hl || el === label || el === hint) return;
    stack = [];
    cur = el;
    draw();
  }

  function swallow(e) {
    e.preventDefault();
    e.stopImmediatePropagation();
    if (e.type === "click" && e.button === 0) finish();
  }

  function onKey(e) {
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopImmediatePropagation();
      cleanup();
    } else if (e.key === "ArrowUp" && cur) {
      e.preventDefault();
      e.stopImmediatePropagation();
      if (cur.parentElement) {
        stack.push(cur);
        cur = cur.parentElement;
        draw();
      }
    } else if (e.key === "ArrowDown" && stack.length) {
      e.preventDefault();
      e.stopImmediatePropagation();
      cur = stack.pop();
      draw();
    } else if (e.key === "Enter") {
      e.preventDefault();
      e.stopImmediatePropagation();
      finish();
    }
  }

  const BLOCK = ["mousedown", "mouseup", "pointerdown", "pointerup", "click", "dblclick", "auxclick", "contextmenu"];

  function cleanup() {
    hl.remove();
    label.remove();
    hint.remove();
    window.removeEventListener("mousemove", onMove, true);
    window.removeEventListener("scroll", draw, true);
    window.removeEventListener("keydown", onKey, true);
    // 決定クリックの後続イベント(mouseup/click)を飲み込み終えてから外す
    setTimeout(() => {
      BLOCK.forEach((t) => window.removeEventListener(t, swallow, true));
    }, 300);
    window.__scshot_element_running = false;
  }

  async function finish() {
    if (finished || !cur) return;
    finished = true;
    const el = cur;
    cleanup();

    const vw = document.documentElement.clientWidth;
    const vh = window.innerHeight;
    let r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return;

    if (r.width <= vw && r.height <= vh) {
      // 画面に収まるサイズ：はみ出していればスクロールして収めてから撮る
      if (r.top < 0 || r.left < 0 || r.bottom > vh || r.right > vw) {
        el.scrollIntoView({ block: "nearest", inline: "nearest", behavior: "instant" });
        await sleep(250);
        r = el.getBoundingClientRect();
      }
      await frame();
      await frame();
      await sleep(30);
      const x = Math.max(0, r.left);
      const y = Math.max(0, r.top);
      chrome.runtime.sendMessage({
        type: "ELEMENT_DONE",
        rect: {
          x,
          y,
          w: Math.min(vw, r.right) - x,
          h: Math.min(vh, r.bottom) - y,
          dpr,
          vw: window.innerWidth,
        },
      });
    } else {
      // 画面より大きい：その範囲だけスクロール撮影
      el.setAttribute("data-scshot-target", "1");
      chrome.runtime.sendMessage({
        type: "ELEMENT_FULL",
        region: {
          x: r.left + window.scrollX,
          y: r.top + window.scrollY,
          w: r.width,
          h: r.height,
        },
      });
    }
  }

  window.addEventListener("mousemove", onMove, true);
  window.addEventListener("scroll", draw, true);
  window.addEventListener("keydown", onKey, true);
  BLOCK.forEach((t) => window.addEventListener(t, swallow, true));
})();
