// content/fullpage.js — ページ全体をスクロールしながら撮影して連結
(() => {
  if (window.__scshot_fullpage_running) return;
  window.__scshot_fullpage_running = true;

  // 要素撮影から呼ばれた場合は、その範囲（ドキュメント座標・CSS px）だけ撮る
  const region = window.__scshot_region || null;
  window.__scshot_region = null;

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const nextFrame = () => new Promise((r) => requestAnimationFrame(() => r()));

  // captureVisibleTab のレート制限(約2回/秒)対策
  const CAPTURE_INTERVAL = 480; // ms（撮影間隔）
  const SETTLE = 160; // ms（スクロール後の描画待ち）

  // キャンバスのサイズ上限（デバイスピクセル）
  const MAX_DIM = 32000;
  const MAX_AREA = 256000000;

  function captureTile() {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ type: "CAPTURE_TILE" }, (res) => {
        if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
        if (!res) return reject(new Error("応答なし"));
        if (res.error) return reject(new Error(res.error));
        resolve(res.dataUrl);
      });
    });
  }

  function loadImage(src) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error("画像読込失敗"));
      img.src = src;
    });
  }

  // 進捗オーバーレイ
  const ov = document.createElement("div");
  Object.assign(ov.style, {
    position: "fixed", left: "0", top: "0", width: "100vw", height: "100vh",
    zIndex: "2147483647", background: "rgba(0,0,0,0.15)", cursor: "progress",
  });
  const badge = document.createElement("div");
  Object.assign(badge.style, {
    position: "fixed", left: "50%", top: "20px", transform: "translateX(-50%)",
    padding: "8px 16px", font: "13px/1.5 -apple-system, sans-serif", color: "#fff",
    background: "rgba(0,0,0,0.8)", borderRadius: "8px", whiteSpace: "nowrap",
  });
  badge.textContent = "ページ全体を撮影中…";
  ov.appendChild(badge);

  // 固定/追従要素を一時的に隠す（複製防止）。撮影対象の要素とその祖先は残す
  function hideFixed() {
    const hidden = [];
    const target = document.querySelector("[data-scshot-target]");
    const all = document.body ? document.body.getElementsByTagName("*") : [];
    for (let i = 0; i < all.length; i++) {
      const el = all[i];
      if (target && (el === target || el.contains(target))) continue;
      const pos = getComputedStyle(el).position;
      if (pos === "fixed" || pos === "sticky") {
        hidden.push([el, el.style.visibility]);
        el.style.visibility = "hidden";
      }
    }
    return hidden;
  }
  function restoreHidden(list) {
    for (const [el, v] of list) el.style.visibility = v;
  }

  async function run() {
    const docEl = document.documentElement;
    const body = document.body;
    const dpr = window.devicePixelRatio || 1;

    // 元の状態を保存
    const orig = {
      x: window.scrollX, y: window.scrollY,
      htmlOverflow: docEl.style.overflow,
      bodyOverflow: body ? body.style.overflow : "",
      scrollBehavior: docEl.style.scrollBehavior,
    };
    docEl.style.scrollBehavior = "auto";

    document.documentElement.appendChild(ov);

    // スクロールバーを消して撮る
    docEl.style.overflow = "hidden";
    if (body) body.style.overflow = "visible";
    await nextFrame();

    const vw = docEl.clientWidth;
    const vh = window.innerHeight;
    const docW = Math.max(
      docEl.scrollWidth, body ? body.scrollWidth : 0, vw
    );
    const docH = Math.max(
      docEl.scrollHeight, body ? body.scrollHeight : 0, vh
    );

    // 撮る範囲（既定はページ全体）
    let rx = 0, ry = 0, totalW = docW, totalH = docH;
    if (region) {
      rx = Math.max(0, Math.min(docW - 1, Math.floor(region.x)));
      ry = Math.max(0, Math.min(docH - 1, Math.floor(region.y)));
      totalW = Math.max(1, Math.min(Math.ceil(region.w), docW - rx));
      totalH = Math.max(1, Math.min(Math.ceil(region.h), docH - ry));
    }

    // 上限クランプ
    let cw = Math.round(totalW * dpr);
    let ch = Math.round(totalH * dpr);
    let clamped = false;
    if (cw > MAX_DIM) { cw = MAX_DIM; totalW = Math.floor(cw / dpr); clamped = true; }
    if (ch > MAX_DIM) { ch = MAX_DIM; totalH = Math.floor(ch / dpr); clamped = true; }
    if (cw * ch > MAX_AREA) {
      const scale = Math.sqrt(MAX_AREA / (cw * ch));
      ch = Math.floor(ch * scale); totalH = Math.floor(ch / dpr); clamped = true;
    }

    // キャンバスは1枚目を撮ってから作る（撮れた画像の実際の倍率に合わせる）
    let canvas = null;
    let ctx = null;
    let k = dpr;

    // タイル座標を列挙
    const xs = [];
    for (let x = rx; x < rx + totalW; x += vw) xs.push(x);
    const ys = [];
    for (let y = ry; y < ry + totalH; y += vh) ys.push(y);
    const total = xs.length * ys.length;

    let hiddenList = [];
    let done = 0;
    let firstCapture = true;
    if (region) {
      // 要素撮影ではヘッダー等の固定要素が最初から重ならないようにする
      hiddenList = hideFixed();
      firstCapture = false;
    }

    try {
      for (let yi = 0; yi < ys.length; yi++) {
        for (let xi = 0; xi < xs.length; xi++) {
          window.scrollTo(xs[xi], ys[yi]);
          await nextFrame();
          await sleep(SETTLE);

          // 2タイル目以降は固定要素を隠す
          if (!firstCapture && hiddenList.length === 0) {
            hiddenList = hideFixed();
            await nextFrame();
          }

          const curX = window.scrollX;
          const curY = window.scrollY;

          // 進捗表示が写り込まないよう、撮る瞬間だけ隠す
          ov.style.visibility = "hidden";
          await nextFrame();
          await nextFrame();
          let dataUrl;
          try {
            dataUrl = await captureTile();
          } catch (e) {
            // レート制限など → 少し待って1回リトライ
            await sleep(1100);
            dataUrl = await captureTile();
          } finally {
            ov.style.visibility = "visible";
          }
          const img = await loadImage(dataUrl);
          if (!canvas) {
            k = img.width / window.innerWidth;
            canvas = document.createElement("canvas");
            canvas.width = Math.max(1, Math.round((cw / dpr) * k));
            canvas.height = Math.max(1, Math.round((ch / dpr) * k));
            ctx = canvas.getContext("2d");
          }
          ctx.drawImage(img, Math.round((curX - rx) * k), Math.round((curY - ry) * k));

          done++;
          badge.textContent = `ページ全体を撮影中… ${done} / ${total}`;
          firstCapture = false;
          await sleep(CAPTURE_INTERVAL);
        }
      }

      restoreHidden(hiddenList);

      badge.textContent = "画像を生成中…";
      const out = canvas.toDataURL("image/png");
      const id = Date.now() + "_" + Math.random().toString(36).slice(2, 7);
      await chrome.storage.local.set({
        ["pending_" + id]: { image: out, clamped, title: document.title, url: location.href },
      });
      chrome.runtime.sendMessage({ type: "FULLPAGE_DONE", id });
    } catch (e) {
      restoreHidden(hiddenList);
      chrome.runtime.sendMessage({ type: "FULLPAGE_ERROR", message: e.message });
    } finally {
      // 後始末
      docEl.style.overflow = orig.htmlOverflow;
      if (body) body.style.overflow = orig.bodyOverflow;
      docEl.style.scrollBehavior = orig.scrollBehavior;
      window.scrollTo(orig.x, orig.y);
      const t = document.querySelector("[data-scshot-target]");
      if (t) t.removeAttribute("data-scshot-target");
      ov.remove();
      window.__scshot_fullpage_running = false;
    }
  }

  run();
})();
