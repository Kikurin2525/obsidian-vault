// editor/db.js — 履歴（直近20枚）を IndexedDB に保存する
const HistoryDB = (() => {
  const NAME = "scshot";
  const STORE = "history";
  const MAX = 20;
  let dbp = null;

  function open() {
    if (dbp) return dbp;
    dbp = new Promise((resolve, reject) => {
      const req = indexedDB.open(NAME, 1);
      req.onupgradeneeded = () => {
        const s = req.result.createObjectStore(STORE, { keyPath: "id" });
        s.createIndex("updatedAt", "updatedAt");
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    return dbp;
  }

  async function run(mode, fn) {
    const db = await open();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, mode);
      const store = tx.objectStore(STORE);
      let result;
      const r = fn(store);
      if (r) r.onsuccess = () => (result = r.result);
      tx.oncomplete = () => resolve(result);
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error);
    });
  }

  const get = (id) => run("readonly", (s) => s.get(id));
  const put = (entry) => run("readwrite", (s) => s.put(entry));
  const remove = (id) => run("readwrite", (s) => s.delete(id));

  // 新しい順（サムネ表示用。画像本体も含む）
  async function list() {
    const all = await run("readonly", (s) => s.getAll());
    return (all || []).sort((a, b) => b.updatedAt - a.updatedAt);
  }

  // 21枚目以降（古いもの）を落とす
  async function prune() {
    const all = await list();
    const old = all.slice(MAX);
    for (const e of old) await remove(e.id);
  }

  return { get, put, remove, list, prune, MAX };
})();
