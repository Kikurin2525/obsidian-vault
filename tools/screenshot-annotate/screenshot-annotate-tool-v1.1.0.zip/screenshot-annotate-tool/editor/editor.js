// editor/editor.js — Fabric.js を使った注釈エディタ（v1.1）
// 開いた瞬間にクリップボードへコピーし、描き足すたびに最新版でコピーし直す。
(function () {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const FONT = '-apple-system, BlinkMacSystemFont, "Hiragino Sans", "Yu Gothic", sans-serif';
  const PROPS = ["kind", "mode", "num"]; // 保存時に残す独自プロパティ
  const CONTINUOUS = new Set(["stamp", "highlight", "blur", "mosaic"]); // 続けて使うツール
  const STYLE_KEY = "scshot_style_v1";

  const canvas = new fabric.Canvas("c", {
    selection: true,
    preserveObjectStacking: true,
    backgroundColor: "#ffffff",
    uniformScaling: false,
  });

  const state = {
    tool: "select",
    stroke: "#ff3b30",
    text: "#ff3b30",
    fill: "#ffd60a",
    fillEnabled: false,
    strokeWidth: 4,
    fontSize: 28,
    zoom: 1,
  };

  let natW = 0,
    natH = 0; // 画像の自然サイズ（出力解像度）
  let bgVersion = 0; // 背景が変わるたびに増やす（ぼかしの作り直し判定）
  const bgStore = new Map(); // bgId -> { blob, url }
  let bgSeq = 0;
  let curBgId = null;
  let ready = false;
  const meta = { id: null, title: "", url: "", createdAt: 0 };

  // ---------- ユーティリティ ----------
  const clamp = (v, min, max) => Math.max(min, Math.min(max, v));

  function mk(w, h) {
    const c = document.createElement("canvas");
    c.width = Math.max(1, Math.round(w));
    c.height = Math.max(1, Math.round(h));
    return c;
  }

  function canvasToBlob(c, type = "image/png", quality) {
    return new Promise((resolve, reject) => {
      c.toBlob((b) => (b ? resolve(b) : reject(new Error("画像の生成に失敗しました"))), type, quality);
    });
  }

  function toast(msg, ms = 1800) {
    const t = $("toast");
    t.textContent = msg;
    t.hidden = false;
    clearTimeout(toast._t);
    toast._t = setTimeout(() => (t.hidden = true), ms);
  }

  function loadImage(src) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error("画像の読み込みに失敗しました"));
      img.src = src;
    });
  }

  function timestamp() {
    const d = new Date();
    const p = (n) => String(n).padStart(2, "0");
    return (
      d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + "_" +
      p(d.getHours()) + p(d.getMinutes()) + p(d.getSeconds())
    );
  }

  function enliven(arr) {
    return new Promise((resolve) => fabric.util.enlivenObjects(arr || [], (objs) => resolve(objs)));
  }

  function contrastText(color) {
    try {
      const [r, g, b] = new fabric.Color(color).getSource();
      return 0.299 * r + 0.587 * g + 0.114 * b > 170 ? "#1c1c1e" : "#ffffff";
    } catch (e) {
      return "#ffffff";
    }
  }

  function toHex(c) {
    if (!c || c === "transparent") return "#000000";
    try {
      return "#" + new fabric.Color(c).toHex().toLowerCase();
    } catch (e) {
      return "#000000";
    }
  }

  // ---------- 色・太さの記憶 ----------
  function loadStyle() {
    try {
      const s = JSON.parse(localStorage.getItem(STYLE_KEY) || "null");
      if (!s) return;
      for (const k of ["stroke", "text", "fill", "fillEnabled", "strokeWidth", "fontSize"]) {
        if (s[k] !== undefined) state[k] = s[k];
      }
    } catch (e) {}
  }
  function saveStyle() {
    try {
      const { stroke, text, fill, fillEnabled, strokeWidth, fontSize } = state;
      localStorage.setItem(STYLE_KEY, JSON.stringify({ stroke, text, fill, fillEnabled, strokeWidth, fontSize }));
    } catch (e) {}
  }
  function syncInputsFromState() {
    $("strokeColor").value = state.stroke;
    $("textColor").value = state.text;
    $("fillColor").value = state.fill;
    $("fillToggle").checked = state.fillEnabled;
    $("strokeWidth").value = state.strokeWidth;
    $("strokeWidthVal").textContent = state.strokeWidth;
    $("fontSize").value = state.fontSize;
    $("fontSizeVal").textContent = state.fontSize;
    document.querySelectorAll(".swatch").forEach((s) => {
      s.classList.toggle("on", s.dataset.color.toLowerCase() === state.stroke.toLowerCase());
    });
  }

  // ---------- 背景画像 ----------
  function addBg(blob) {
    const id = "bg" + ++bgSeq;
    bgStore.set(id, { blob, url: URL.createObjectURL(blob) });
    return id;
  }

  function setBackground(bgId) {
    return new Promise((resolve, reject) => {
      const entry = bgStore.get(bgId);
      fabric.Image.fromURL(entry.url, (img) => {
        if (!img || !img.width) return reject(new Error("画像の読み込みに失敗しました"));
        natW = img.width;
        natH = img.height;
        curBgId = bgId;
        bgVersion++;
        canvas.setBackgroundImage(
          img,
          () => {
            applyZoom(state.zoom);
            resolve();
          },
          { originX: "left", originY: "top" }
        );
      });
    });
  }

  // crop指定があれば切り抜いて PNG Blob を返す
  async function prepareImage(pending) {
    if (!pending.crop) return (await fetch(pending.image)).blob();
    const img = await loadImage(pending.image);
    const { x, y, w, h, dpr, vw } = pending.crop;
    // 画面の幅と撮れた画像の幅から倍率を出す（ページの拡大縮小にも追従）
    const k = vw ? img.width / vw : dpr || 1;
    const sx = clamp(Math.round(x * k), 0, img.width - 1);
    const sy = clamp(Math.round(y * k), 0, img.height - 1);
    const sw = clamp(Math.round(w * k), 1, img.width - sx);
    const sh = clamp(Math.round(h * k), 1, img.height - sy);
    const tmp = mk(sw, sh);
    tmp.getContext("2d").drawImage(img, sx, sy, sw, sh, 0, 0, sw, sh);
    return canvasToBlob(tmp, "image/png");
  }

  // ---------- ぼかし・モザイク ----------
  // 背景画像の該当範囲をその場で加工して描く（移動・リサイズしても追従）
  function blurCacheFor(obj) {
    const bg = canvas.backgroundImage;
    if (!bg) return null;
    const el = bg.getElement();
    const d = fabric.util.qrDecompose(obj.calcTransformMatrix());
    const sw = Math.abs(obj.width * d.scaleX);
    const sh = Math.abs(obj.height * d.scaleY);
    const X = Math.round(d.translateX - sw / 2);
    const Y = Math.round(d.translateY - sh / 2);
    const W = Math.max(1, Math.round(sw));
    const H = Math.max(1, Math.round(sh));
    const key = [bgVersion, X, Y, W, H, obj.mode].join(",");
    if (obj._bcKey === key) return obj._bc;

    const out = mk(W, H);
    const x0 = clamp(X, 0, natW),
      y0 = clamp(Y, 0, natH);
    const x1 = clamp(X + W, 0, natW),
      y1 = clamp(Y + H, 0, natH);
    const cw = x1 - x0,
      ch = y1 - y0;
    if (cw >= 1 && ch >= 1) {
      const octx = out.getContext("2d");
      const ox = x0 - X,
        oy = y0 - Y;
      if (obj.mode === "mosaic") {
        const B = clamp(Math.round(Math.min(cw, ch) / 5), 10, 28);
        const sm = mk(Math.ceil(cw / B), Math.ceil(ch / B));
        const sctx = sm.getContext("2d");
        sctx.imageSmoothingEnabled = true;
        sctx.imageSmoothingQuality = "high";
        sctx.drawImage(el, x0, y0, cw, ch, 0, 0, sm.width, sm.height);
        octx.imageSmoothingEnabled = false;
        octx.drawImage(sm, 0, 0, sm.width, sm.height, ox, oy, cw, ch);
      } else {
        const sigma = clamp(Math.round(Math.min(cw, ch) / 6), 8, 30);
        const R = sigma * 3;
        const p = mk(cw + 2 * R, ch + 2 * R);
        const pc = p.getContext("2d");
        pc.drawImage(el, x0, y0, cw, ch, R, R, cw, ch);
        // 端の1pxを外側へ引き伸ばす（ぼかしの縁が透けて元の文字が見えないように）
        pc.drawImage(el, x0, y0, 1, ch, 0, R, R, ch);
        pc.drawImage(el, x1 - 1, y0, 1, ch, R + cw, R, R, ch);
        pc.drawImage(el, x0, y0, cw, 1, R, 0, cw, R);
        pc.drawImage(el, x0, y1 - 1, cw, 1, R, R + ch, cw, R);
        pc.drawImage(el, x0, y0, 1, 1, 0, 0, R, R);
        pc.drawImage(el, x1 - 1, y0, 1, 1, R + cw, 0, R, R);
        pc.drawImage(el, x0, y1 - 1, 1, 1, 0, R + ch, R, R);
        pc.drawImage(el, x1 - 1, y1 - 1, 1, 1, R + cw, R + ch, R, R);
        octx.save();
        octx.beginPath();
        octx.rect(ox, oy, cw, ch);
        octx.clip();
        octx.filter = `blur(${sigma}px)`;
        octx.drawImage(p, ox - R, oy - R);
        octx.restore();
      }
    }
    obj._bc = out;
    obj._bcKey = key;
    return out;
  }

  fabric.BlurBox = fabric.util.createClass(fabric.Rect, {
    type: "blurBox",
    initialize(options) {
      this.callSuper(
        "initialize",
        Object.assign(
          {
            fill: "rgba(0,0,0,0)",
            stroke: null,
            strokeWidth: 0,
            lockRotation: true,
            objectCaching: false,
            mode: "blur",
            kind: "blur",
          },
          options || {}
        )
      );
      this.setControlsVisibility({ mtr: false });
    },
    toObject(props) {
      return this.callSuper("toObject", ["mode", "kind"].concat(props || []));
    },
    _render(ctx) {
      const w = this.width,
        h = this.height;
      const cache = blurCacheFor(this);
      if (cache) ctx.drawImage(cache, -w / 2, -h / 2, w, h);
    },
  });
  fabric.BlurBox.fromObject = (obj, cb) => fabric.Object._fromObject("BlurBox", obj, cb);

  // ---------- 切り抜き枠（外側を暗くする） ----------
  fabric.CropBox = fabric.util.createClass(fabric.Rect, {
    type: "cropBox",
    initialize(options) {
      this.callSuper(
        "initialize",
        Object.assign(
          {
            fill: "rgba(0,0,0,0)",
            stroke: null,
            strokeWidth: 0,
            lockRotation: true,
            objectCaching: false,
            kind: "cropbox",
            borderColor: "#ffffff",
            cornerColor: "#ffffff",
            cornerStrokeColor: "#22a565",
            transparentCorners: false,
            hoverCursor: "move",
          },
          options || {}
        )
      );
      this.setControlsVisibility({ mtr: false });
    },
    _render(ctx) {
      const w = this.width,
        h = this.height;
      const z = (this.canvas ? this.canvas.getZoom() : 1) * (Math.abs(this.scaleX) || 1);
      ctx.save();
      ctx.beginPath();
      ctx.rect(-1e5, -1e5, 2e5, 2e5);
      ctx.rect(-w / 2, -h / 2, w, h);
      ctx.fillStyle = "rgba(0,0,0,0.55)";
      ctx.fill("evenodd");
      ctx.strokeStyle = "#ffffff";
      ctx.lineWidth = 1.5 / z;
      ctx.setLineDash([6 / z, 4 / z]);
      ctx.strokeRect(-w / 2, -h / 2, w, h);
      ctx.restore();
    },
  });

  // ---------- ズーム ----------
  function applyZoom(z) {
    state.zoom = z;
    canvas.setZoom(z);
    canvas.setDimensions({ width: Math.round(natW * z), height: Math.round(natH * z) });
    $("zoomLabel").textContent = Math.round(z * 100) + "%";
    canvas.requestRenderAll();
  }

  function fitToScreen() {
    const stage = $("stage");
    const availW = stage.clientWidth - 80;
    const availH = stage.clientHeight - 120;
    let z = Math.min(availW / natW, availH / natH, 1);
    if (!isFinite(z) || z <= 0) z = 1;
    applyZoom(z);
  }

  $("zoomIn").onclick = () => applyZoom(Math.min(state.zoom * 1.25, 8));
  $("zoomOut").onclick = () => applyZoom(Math.max(state.zoom / 1.25, 0.05));
  $("zoomFit").onclick = fitToScreen;
  $("zoom100").onclick = () => applyZoom(1);

  // トラックパッドのピンチ（ctrl+wheel）で拡大縮小
  $("stage").addEventListener(
    "wheel",
    (e) => {
      if (!e.ctrlKey || !natW) return;
      e.preventDefault();
      applyZoom(clamp(state.zoom * Math.exp(-e.deltaY * 0.01), 0.05, 8));
    },
    { passive: false }
  );

  // ---------- ツール選択 ----------
  function setTool(tool) {
    if (state.tool === "crop" && tool !== "crop") removeCropBox();
    state.tool = tool;
    document.querySelectorAll(".tool").forEach((b) => {
      b.classList.toggle("active", b.dataset.tool === tool);
    });
    const drawing = tool !== "select";
    canvas.selection = !drawing;
    canvas.defaultCursor = drawing ? "crosshair" : "default";
    canvas.hoverCursor = drawing ? "crosshair" : "move";
    canvas.forEachObject((o) => (o.selectable = !drawing || o.kind === "cropbox"));
    canvas.discardActiveObject();
    canvas.requestRenderAll();
  }

  document.querySelectorAll(".tool").forEach((btn) => {
    btn.onclick = () => setTool(btn.dataset.tool);
  });

  canvas.on("object:added", (e) => {
    const o = e.target;
    o.selectable = state.tool === "select" || o.kind === "cropbox";
  });

  // ---------- 矢印（Line + Triangle のグループ） ----------
  function makeArrow(x1, y1, x2, y2, color, width) {
    const angle = Math.atan2(y2 - y1, x2 - x1);
    const headLen = Math.max(12, width * 3.2);
    // 矢じり分だけ線を短くして重なりを防ぐ
    const lx2 = x2 - Math.cos(angle) * headLen * 0.6;
    const ly2 = y2 - Math.sin(angle) * headLen * 0.6;
    const line = new fabric.Line([x1, y1, lx2, ly2], {
      stroke: color,
      strokeWidth: width,
      strokeLineCap: "round",
    });
    const head = new fabric.Triangle({
      left: x2,
      top: y2,
      originX: "center",
      originY: "center",
      angle: (angle * 180) / Math.PI + 90,
      width: headLen,
      height: headLen,
      fill: color,
    });
    const group = new fabric.Group([line, head], { lockScalingFlip: true });
    group.kind = "arrow";
    return group;
  }

  function setArrowColor(group, color) {
    group.getObjects().forEach((o) => {
      if (o.type === "line") o.set("stroke", color);
      else o.set("fill", color);
    });
    group.dirty = true;
  }

  // いまの見た目どおりの始点・先端を取り出す（移動・拡大後でもOK）
  function arrowEndpoints(group) {
    const [line, head] = group.getObjects();
    const lp = line.calcLinePoints();
    const start = fabric.util.transformPoint(new fabric.Point(lp.x1, lp.y1), line.calcTransformMatrix());
    const hm = head.calcTransformMatrix();
    return { start, tip: new fabric.Point(hm[4], hm[5]), color: line.stroke };
  }

  function replaceObject(oldObj, newObj) {
    const idx = canvas.getObjects().indexOf(oldObj);
    canvas.remove(oldObj);
    canvas.insertAt(newObj, idx < 0 ? canvas.getObjects().length : idx);
    return newObj;
  }

  // ---------- 番号スタンプ ----------
  function makeStamp(x, y, num, color, size) {
    const r = Math.max(10, size * 0.62);
    const circle = new fabric.Circle({
      left: x,
      top: y,
      originX: "center",
      originY: "center",
      radius: r,
      fill: color,
      stroke: "#ffffff",
      strokeWidth: Math.max(2, r * 0.14),
      shadow: new fabric.Shadow({ color: "rgba(0,0,0,0.35)", blur: r * 0.4, offsetX: 0, offsetY: r * 0.08 }),
    });
    const text = new fabric.Text(String(num), {
      left: x,
      top: y,
      originX: "center",
      originY: "center",
      fontSize: r * (num >= 10 ? 1.0 : 1.2),
      lineHeight: 1,
      fontWeight: "700",
      fill: contrastText(color),
      fontFamily: FONT,
    });
    const g = new fabric.Group([circle, text], { lockScalingFlip: true });
    g.kind = "stamp";
    g.num = num;
    return g;
  }

  function setStampColor(g, color) {
    const [circle, text] = g.getObjects();
    circle.set("fill", color);
    text.set("fill", contrastText(color));
    g.dirty = true;
  }

  function nextStampNumber() {
    let max = 0;
    canvas.getObjects().forEach((o) => {
      if (o.kind === "stamp" && o.num > max) max = o.num;
    });
    return max + 1;
  }

  // ---------- 蛍光ペン ----------
  function makeHighlight(p) {
    const r = new fabric.Rect({
      left: p.x,
      top: p.y,
      width: 1,
      height: 1,
      rx: 3,
      ry: 3,
      fill: state.fill,
      opacity: 0.45,
      strokeWidth: 0,
      stroke: null,
      globalCompositeOperation: "multiply",
    });
    r.kind = "highlight";
    return r;
  }

  // ---------- 描画インタラクション ----------
  let drawing = null; // { tool, origin, shape }

  canvas.on("mouse:down", (opt) => {
    if (!ready) return;
    const tool = state.tool;
    if (tool === "select") return;
    if (tool === "crop" && opt.target && opt.target.kind === "cropbox") return; // 枠の調整
    const p = canvas.getPointer(opt.e);

    if (tool === "text") {
      const t = new fabric.IText("テキスト", {
        left: p.x,
        top: p.y,
        fill: state.text,
        fontSize: state.fontSize,
        fontFamily: FONT,
        editable: true,
      });
      canvas.add(t);
      setTool("select");
      canvas.setActiveObject(t);
      t.enterEditing();
      t.selectAll();
      canvas.requestRenderAll();
      t.once("editing:exited", () => {
        if (!t.text || !t.text.trim()) canvas.remove(t);
        pushHistory();
      });
      return;
    }

    if (tool === "stamp") {
      canvas.add(makeStamp(p.x, p.y, nextStampNumber(), state.stroke, state.fontSize));
      canvas.requestRenderAll();
      pushHistory();
      return;
    }

    const fill = state.fillEnabled ? state.fill : "transparent";
    let shape = null;
    if (tool === "rect") {
      shape = new fabric.Rect({
        left: p.x, top: p.y, width: 1, height: 1, rx: 10, ry: 10,
        stroke: state.stroke, strokeWidth: state.strokeWidth, fill, strokeUniform: true,
      });
    } else if (tool === "ellipse") {
      shape = new fabric.Ellipse({
        left: p.x, top: p.y, rx: 1, ry: 1,
        stroke: state.stroke, strokeWidth: state.strokeWidth, fill, strokeUniform: true,
      });
    } else if (tool === "line") {
      shape = new fabric.Line([p.x, p.y, p.x, p.y], {
        stroke: state.stroke, strokeWidth: state.strokeWidth, strokeLineCap: "round",
      });
    } else if (tool === "arrow") {
      shape = makeArrow(p.x, p.y, p.x + 1, p.y + 1, state.stroke, state.strokeWidth);
    } else if (tool === "highlight") {
      shape = makeHighlight(p);
    } else if (tool === "blur" || tool === "mosaic") {
      shape = new fabric.BlurBox({ left: p.x, top: p.y, width: 1, height: 1, mode: tool });
    } else if (tool === "crop") {
      removeCropBox();
      shape = new fabric.CropBox({ left: p.x, top: p.y, width: 1, height: 1 });
    }
    if (!shape) return;
    canvas.add(shape);
    shape.selectable = false; // 描いている間は掴めないように
    drawing = { tool, origin: p, shape };
  });

  canvas.on("mouse:move", (opt) => {
    if (!drawing) return;
    const { tool, origin } = drawing;
    let p = canvas.getPointer(opt.e);
    if (tool === "crop") p = { x: clamp(p.x, 0, natW), y: clamp(p.y, 0, natH) };
    const left = Math.min(origin.x, p.x);
    const top = Math.min(origin.y, p.y);
    const w = Math.abs(p.x - origin.x);
    const h = Math.abs(p.y - origin.y);
    const shape = drawing.shape;

    if (tool === "ellipse") {
      shape.set({ left, top, rx: w / 2, ry: h / 2 });
    } else if (tool === "line") {
      shape.set({ x2: p.x, y2: p.y });
    } else if (tool === "arrow") {
      canvas.remove(shape);
      drawing.shape = makeArrow(origin.x, origin.y, p.x, p.y, state.stroke, state.strokeWidth);
      canvas.add(drawing.shape);
      drawing.shape.selectable = false;
    } else {
      shape.set({ left, top, width: w, height: h });
    }
    drawing.shape.setCoords();
    canvas.requestRenderAll();
  });

  canvas.on("mouse:up", () => {
    if (!drawing) return;
    const { tool, shape } = drawing;
    drawing = null;

    const b = shape.getBoundingRect(true, true);
    if (b.width < 5 && b.height < 5) {
      canvas.remove(shape); // クリックだけなら描かない
      canvas.requestRenderAll();
      return;
    }
    shape.setCoords();

    if (tool === "crop") {
      shape.selectable = true;
      canvas.setActiveObject(shape);
      showCropBar(true);
      canvas.requestRenderAll();
      return;
    }
    if (tool === "blur" || tool === "mosaic") canvas.sendToBack(shape); // 注釈より下に
    if (CONTINUOUS.has(tool)) {
      canvas.requestRenderAll();
      pushHistory();
      return;
    }
    setTool("select");
    canvas.setActiveObject(shape);
    canvas.requestRenderAll();
    pushHistory();
  });

  // ---------- 切り抜き ----------
  function getCropBox() {
    return canvas.getObjects().find((o) => o.kind === "cropbox");
  }
  function showCropBar(on) {
    $("cropBar").hidden = !on;
  }
  function removeCropBox() {
    const c = getCropBox();
    if (c) canvas.remove(c);
    showCropBar(false);
    canvas.requestRenderAll();
  }

  async function applyCrop() {
    const cb = getCropBox();
    if (!cb) return;
    const r = cb.getBoundingRect(true, true);
    const x = clamp(Math.round(r.left), 0, natW - 1);
    const y = clamp(Math.round(r.top), 0, natH - 1);
    const w = clamp(Math.round(r.left + r.width), 1, natW) - x;
    const h = clamp(Math.round(r.top + r.height), 1, natH) - y;
    if (w < 2 || h < 2) {
      toast("切り抜く範囲が小さすぎます");
      return;
    }
    canvas.discardActiveObject();
    canvas.remove(cb);
    showCropBar(false);

    const el = canvas.backgroundImage.getElement();
    const c = mk(w, h);
    c.getContext("2d").drawImage(el, x, y, w, h, 0, 0, w, h);
    const id = addBg(await canvasToBlob(c, "image/png"));
    canvas.getObjects().forEach((o) => {
      o.set({ left: o.left - x, top: o.top - y });
      o.setCoords();
    });
    await setBackground(id);
    setTool("select");
    fitToScreen();
    pushHistory();
    toast("切り抜きました（⌘Zで戻せます）");
  }
  $("cropApply").onclick = applyCrop;
  $("cropCancel").onclick = () => setTool("select");

  // ---------- 選択中オブジェクトへの色・スタイル反映 ----------
  function activeObjects() {
    const a = canvas.getActiveObject();
    if (!a) return [];
    if (a.type === "activeSelection") return a.getObjects();
    return [a];
  }

  function applyToActive(fn) {
    const objs = activeObjects();
    if (!objs.length) return false;
    objs.forEach(fn);
    canvas.requestRenderAll();
    return true;
  }

  function applyStrokeColor(o, c) {
    if (o.kind === "arrow") setArrowColor(o, c);
    else if (o.kind === "stamp") setStampColor(o, c);
    else if (o.type === "rect" || o.type === "ellipse" || o.type === "line") {
      if (o.kind !== "highlight") o.set("stroke", c);
    }
  }

  function setStrokeColor(c, alsoText) {
    state.stroke = c;
    if (alsoText) state.text = c;
    applyToActive((o) => {
      applyStrokeColor(o, c);
      if (alsoText && o.type === "i-text") o.set("fill", c);
    });
    syncInputsFromState();
    saveStyle();
  }

  // スライダーやカラーピッカーを動かし終えたら1回だけ履歴に積む
  function commitIfSelected() {
    if (activeObjects().length) pushHistory();
  }

  document.querySelectorAll(".swatch").forEach((s) => {
    s.onclick = () => {
      setStrokeColor(s.dataset.color, true);
      commitIfSelected();
    };
  });

  $("strokeColor").addEventListener("input", (e) => setStrokeColor(e.target.value, false));
  $("strokeColor").addEventListener("change", commitIfSelected);

  $("textColor").addEventListener("input", (e) => {
    state.text = e.target.value;
    applyToActive((o) => {
      if (o.type === "i-text") o.set("fill", state.text);
    });
    saveStyle();
  });
  $("textColor").addEventListener("change", commitIfSelected);

  $("fillColor").addEventListener("input", (e) => {
    state.fill = e.target.value;
    applyToActive((o) => {
      if (o.kind === "highlight") o.set("fill", state.fill);
      else if (o.type === "rect" || o.type === "ellipse") {
        o.set("fill", state.fill);
        state.fillEnabled = true;
      }
    });
    $("fillToggle").checked = state.fillEnabled;
    saveStyle();
  });
  $("fillColor").addEventListener("change", commitIfSelected);

  $("fillToggle").addEventListener("change", (e) => {
    state.fillEnabled = e.target.checked;
    applyToActive((o) => {
      if (o.kind !== "highlight" && (o.type === "rect" || o.type === "ellipse")) {
        o.set("fill", state.fillEnabled ? state.fill : "transparent");
      }
    });
    saveStyle();
    commitIfSelected();
  });

  $("strokeWidth").addEventListener("input", (e) => {
    state.strokeWidth = parseInt(e.target.value, 10);
    $("strokeWidthVal").textContent = state.strokeWidth;
    const objs = activeObjects();
    if (objs.length === 1 && objs[0].kind === "arrow") {
      // 矢じりも太さに合わせて作り直す
      const { start, tip, color } = arrowEndpoints(objs[0]);
      const na = replaceObject(objs[0], makeArrow(start.x, start.y, tip.x, tip.y, color, state.strokeWidth));
      canvas.setActiveObject(na);
    } else {
      objs.forEach((o) => {
        if (o.kind === "arrow") {
          o.getObjects().forEach((c) => c.type === "line" && c.set("strokeWidth", state.strokeWidth));
          o.dirty = true;
        } else if (o.type === "rect" || o.type === "ellipse" || o.type === "line") {
          if (o.kind !== "highlight") o.set("strokeWidth", state.strokeWidth);
        }
      });
    }
    canvas.requestRenderAll();
    saveStyle();
  });
  $("strokeWidth").addEventListener("change", commitIfSelected);

  $("fontSize").addEventListener("input", (e) => {
    state.fontSize = parseInt(e.target.value, 10);
    $("fontSizeVal").textContent = state.fontSize;
    const objs = activeObjects();
    if (objs.length === 1 && objs[0].kind === "stamp") {
      const g = objs[0];
      const c = g.getCenterPoint();
      const ns = replaceObject(g, makeStamp(c.x, c.y, g.num, g.getObjects()[0].fill, state.fontSize));
      canvas.setActiveObject(ns);
    } else {
      objs.forEach((o) => o.type === "i-text" && o.set("fontSize", state.fontSize));
    }
    canvas.requestRenderAll();
    saveStyle();
  });
  $("fontSize").addEventListener("change", commitIfSelected);

  // 選択したら、ツールバーをその図形の設定に合わせる
  function syncControls() {
    const objs = activeObjects();
    if (objs.length !== 1) return;
    const o = objs[0];
    if (o.type === "i-text") {
      state.text = toHex(o.fill);
      state.fontSize = Math.round(o.fontSize);
    } else if (o.kind === "arrow") {
      const line = o.getObjects().find((c) => c.type === "line");
      if (line) {
        state.stroke = toHex(line.stroke);
        state.strokeWidth = line.strokeWidth;
      }
    } else if (o.kind === "stamp") {
      state.stroke = toHex(o.getObjects()[0].fill);
    } else if (o.kind === "highlight") {
      state.fill = toHex(o.fill);
    } else if (o.type === "rect" || o.type === "ellipse" || o.type === "line") {
      if (o.stroke) state.stroke = toHex(o.stroke);
      state.strokeWidth = o.strokeWidth;
      if (o.type !== "line") {
        state.fillEnabled = !!o.fill && o.fill !== "transparent";
        if (state.fillEnabled) state.fill = toHex(o.fill);
      }
    } else {
      return;
    }
    syncInputsFromState();
  }
  canvas.on("selection:created", syncControls);
  canvas.on("selection:updated", syncControls);

  // 移動・変形後に履歴
  canvas.on("object:modified", (e) => {
    if (e.target && e.target.kind === "cropbox") return;
    pushHistory();
  });

  // ---------- 削除 ----------
  function deleteActive() {
    const objs = activeObjects();
    if (!objs.length) return;
    if (objs.some((o) => o.kind === "cropbox")) {
      setTool("select");
      return;
    }
    objs.forEach((o) => canvas.remove(o));
    canvas.discardActiveObject();
    canvas.requestRenderAll();
    pushHistory();
  }
  $("delete").onclick = deleteActive;

  // ---------- Undo / Redo ----------
  let undoStack = [];
  let uindex = -1;
  let restoring = false;

  function snapshot() {
    return {
      bgId: curBgId,
      objects: canvas
        .getObjects()
        .filter((o) => o.kind !== "cropbox")
        .map((o) => canvas._toObject(o, "toObject", PROPS)),
    };
  }

  function pushHistory(silent) {
    if (restoring) return;
    undoStack = undoStack.slice(0, uindex + 1);
    undoStack.push(snapshot());
    if (undoStack.length > 60) undoStack.shift();
    uindex = undoStack.length - 1;
    if (!silent) markDirty();
  }

  async function restore(index) {
    if (restoring || index < 0 || index >= undoStack.length) return;
    restoring = true;
    try {
      const snap = undoStack[index];
      canvas.discardActiveObject();
      showCropBar(false);
      canvas.getObjects().slice().forEach((o) => canvas.remove(o));
      if (snap.bgId !== curBgId) {
        await setBackground(snap.bgId);
        fitToScreen();
      }
      const objs = await enliven(snap.objects);
      objs.forEach((o) => canvas.add(o));
      uindex = index;
      canvas.requestRenderAll();
    } finally {
      restoring = false;
    }
    markDirty();
  }

  const undo = () => restore(uindex - 1);
  const redo = () => restore(uindex + 1);
  $("undo").onclick = undo;
  $("redo").onclick = redo;

  // ---------- 書き出し ----------
  // ズームに関係なく、自然サイズ × scale で描いたキャンバスを返す（選択枠は写らない）
  function renderAt(scale = 1) {
    const out = mk(natW * scale, natH * scale);
    const saved = {
      vpt: canvas.viewportTransform,
      width: canvas.width,
      height: canvas.height,
      interactive: canvas.interactive,
      retina: canvas.enableRetinaScaling,
      top: canvas.contextTop,
    };
    canvas.contextTop = null;
    canvas.enableRetinaScaling = false;
    canvas.interactive = false;
    canvas.viewportTransform = [scale, 0, 0, scale, 0, 0];
    canvas.width = out.width;
    canvas.height = out.height;
    canvas.calcViewportBoundaries();
    try {
      canvas.renderCanvas(
        out.getContext("2d"),
        canvas.getObjects().filter((o) => o.kind !== "cropbox")
      );
    } finally {
      canvas.viewportTransform = saved.vpt;
      canvas.width = saved.width;
      canvas.height = saved.height;
      canvas.interactive = saved.interactive;
      canvas.enableRetinaScaling = saved.retina;
      canvas.contextTop = saved.top;
      canvas.calcViewportBoundaries();
      // renderCanvas は予約済みの画面描画を取り消すので、描き直しを予約し直す
      canvas.requestRenderAll();
    }
    return out;
  }

  // ---------- クリップボード ----------
  let copyPending = false;

  function setCopyState(s) {
    const el = $("copyState");
    el.className = "copy-state " + s;
    el.textContent = s === "ok" ? "✓ コピー済み" : s === "ng" ? "⚠ 未コピー（クリック）" : "…";
  }

  async function copyCanvas(c, showToast) {
    setCopyState("wait");
    try {
      await navigator.clipboard.write([new ClipboardItem({ "image/png": canvasToBlob(c, "image/png") })]);
      copyPending = false;
      setCopyState("ok");
      if (showToast) toast("クリップボードにコピーしました");
    } catch (e) {
      // タブにフォーカスがない等。フォーカスが戻ったら自動でやり直す
      copyPending = true;
      setCopyState("ng");
      if (showToast) toast("コピーできませんでした: " + e.message, 2600);
    }
  }

  function copyNow(showToast) {
    if (!ready) return;
    copyCanvas(renderAt(1), showToast);
  }

  $("copyBtn").onclick = () => copyNow(true);
  $("copyState").onclick = () => copyNow(true);
  window.addEventListener("focus", () => {
    if (copyPending && ready) copyNow(false);
  });

  // ---------- 自動コピー＋履歴保存 ----------
  let dirtyTimer = null;
  let pruned = false;

  function markDirty() {
    if (!ready) return;
    clearTimeout(dirtyTimer);
    setCopyState("wait");
    dirtyTimer = setTimeout(flush, 600);
  }

  function flush() {
    const a = canvas.getActiveObject();
    if (a && a.isEditing) {
      dirtyTimer = setTimeout(flush, 800); // 文字入力中は待つ
      return;
    }
    const full = renderAt(1);
    copyCanvas(full, false);
    saveEntry(full);
  }

  async function saveEntry(full) {
    try {
      const bg = bgStore.get(curBgId);
      const scale = Math.min(1, 480 / natW);
      const tw = Math.max(1, Math.round(natW * scale));
      const th = Math.max(1, Math.min(Math.round(natH * scale), 360));
      const t = mk(tw, th);
      const tctx = t.getContext("2d");
      tctx.imageSmoothingQuality = "high";
      tctx.drawImage(full, 0, 0, natW, th / scale, 0, 0, tw, th);
      await HistoryDB.put({
        id: meta.id,
        title: meta.title,
        url: meta.url,
        createdAt: meta.createdAt,
        updatedAt: Date.now(),
        w: natW,
        h: natH,
        bg: bg.blob,
        objects: undoStack[uindex] ? undoStack[uindex].objects : [],
        thumb: t.toDataURL("image/jpeg", 0.8),
      });
      if (!pruned) {
        pruned = true;
        await HistoryDB.prune();
      }
    } catch (e) {
      console.warn("履歴の保存に失敗:", e);
    }
  }

  // ---------- 保存（ダウンロードフォルダへ直接） ----------
  function fileBase() {
    const t = (meta.title || "")
      .replace(/[\\/:*?"<>|~\u0000-\u001f]/g, "")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 40)
      .replace(/^[.\s]+|[.\s]+$/g, "");
    return t ? `スクショ_${t}_${timestamp()}` : `スクショ_${timestamp()}`;
  }

  async function saveToDownloads(blob, ext, label) {
    const url = URL.createObjectURL(blob);
    const opts = { url, saveAs: false, conflictAction: "uniquify" };
    try {
      await chrome.downloads.download({ ...opts, filename: `${fileBase()}.${ext}` });
      toast(`${label}をダウンロードフォルダに保存しました`);
    } catch (e) {
      try {
        // ページ名に使えない文字があった場合は日時だけの名前で保存
        await chrome.downloads.download({ ...opts, filename: `スクショ_${timestamp()}.${ext}` });
        toast(`${label}をダウンロードフォルダに保存しました`);
      } catch (e2) {
        toast("保存に失敗: " + e2.message, 2600);
      }
    } finally {
      setTimeout(() => URL.revokeObjectURL(url), 60000);
    }
  }

  async function savePng() {
    if (!ready) return;
    await saveToDownloads(await canvasToBlob(renderAt(1), "image/png"), "png", "PNG");
  }

  async function saveJpeg() {
    if (!ready) return;
    await saveToDownloads(await canvasToBlob(renderAt(1), "image/jpeg", 0.92), "jpg", "JPEG");
  }

  async function savePdf() {
    if (!ready) return;
    try {
      const jpegBlob = await canvasToBlob(renderAt(1), "image/jpeg", 0.92);
      const jpeg = new Uint8Array(await jpegBlob.arrayBuffer());
      await saveToDownloads(buildImagePdf(jpeg, natW, natH), "pdf", "PDF");
    } catch (e) {
      toast("PDF生成に失敗: " + e.message, 2600);
    }
  }

  $("pngBtn").onclick = savePng;
  $("jpegBtn").onclick = saveJpeg;
  $("pdfBtn").onclick = savePdf;
  $("historyBtn").onclick = () => chrome.tabs.create({ url: chrome.runtime.getURL("editor/history.html") });

  // ---------- キーボード ----------
  const KEY_TOOLS = {
    v: "select", a: "arrow", r: "rect", o: "ellipse", l: "line", t: "text",
    n: "stamp", h: "highlight", b: "blur", m: "mosaic", c: "crop",
  };

  document.addEventListener("keydown", (e) => {
    const active = canvas.getActiveObject();
    if (active && active.isEditing) return; // テキスト編集中は介入しない
    const mod = e.metaKey || e.ctrlKey;
    const tag = (e.target && e.target.tagName) || "";
    const inField = tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT";
    if (inField && !mod) return;
    const k = e.key.toLowerCase();

    if (state.tool === "crop" && getCropBox() && !mod) {
      if (e.key === "Enter") {
        e.preventDefault();
        applyCrop();
        return;
      }
      if (e.key === "Escape") {
        e.preventDefault();
        setTool("select");
        return;
      }
    }

    if ((e.key === "Delete" || e.key === "Backspace") && !mod) {
      e.preventDefault();
      deleteActive();
    } else if (mod && k === "z") {
      e.preventDefault();
      e.shiftKey ? redo() : undo();
    } else if (mod && k === "c") {
      e.preventDefault();
      copyNow(true);
    } else if (mod && k === "s") {
      e.preventDefault();
      savePng();
    } else if (mod) {
      return;
    } else if (e.key.startsWith("Arrow") && active) {
      e.preventDefault();
      const step = e.shiftKey ? 10 : 1;
      const dx = e.key === "ArrowLeft" ? -step : e.key === "ArrowRight" ? step : 0;
      const dy = e.key === "ArrowUp" ? -step : e.key === "ArrowDown" ? step : 0;
      active.set({ left: active.left + dx, top: active.top + dy });
      active.setCoords();
      canvas.requestRenderAll();
      if (active.kind !== "cropbox") pushHistory();
    } else if (e.key === "Escape") {
      setTool("select");
    } else if (KEY_TOOLS[k]) {
      e.preventDefault();
      setTool(KEY_TOOLS[k]);
    }
  });

  // ---------- 起動 ----------
  async function initFromPending(pid) {
    const key = "pending_" + pid;
    const data = await chrome.storage.local.get(key);
    const pending = data[key];
    if (!pending || !pending.image) throw new Error("キャプチャ画像が見つかりません");
    await chrome.storage.local.remove(key);
    const blob = await prepareImage(pending);
    meta.id = pid;
    meta.title = pending.title || "";
    meta.url = pending.url || "";
    meta.createdAt = Date.now();
    await setBackground(addBg(blob));
    fitToScreen();
    // 再読み込みしても履歴から開き直せるように
    window.history.replaceState(null, "", "?h=" + encodeURIComponent(meta.id));
    if (pending.clamped) toast("ページが大きいため一部を縮小しました", 2600);
    return [];
  }

  async function initFromHistory(hid) {
    const entry = await HistoryDB.get(hid);
    if (!entry) throw new Error("履歴が見つかりません");
    meta.id = entry.id;
    meta.title = entry.title || "";
    meta.url = entry.url || "";
    meta.createdAt = entry.createdAt || Date.now();
    await setBackground(addBg(entry.bg));
    fitToScreen();
    return entry.objects || [];
  }

  async function init() {
    loadStyle();
    syncInputsFromState();
    const params = new URLSearchParams(location.search);
    try {
      let objects;
      if (params.get("p")) objects = await initFromPending(params.get("p"));
      else if (params.get("h")) objects = await initFromHistory(params.get("h"));
      else throw new Error("画像の指定がありません");
      const objs = await enliven(objects);
      objs.forEach((o) => canvas.add(o));
    } catch (e) {
      console.warn(e);
      $("empty").hidden = false;
      $("canvasWrap").style.display = "none";
      return;
    }
    document.title = meta.title ? `スクショ編集 – ${meta.title}` : "スクショ編集";
    ready = true;
    pushHistory(true); // 初期状態
    const full = renderAt(1);
    copyCanvas(full, false); // 撮った瞬間にコピー
    saveEntry(full);
  }

  init();
})();
