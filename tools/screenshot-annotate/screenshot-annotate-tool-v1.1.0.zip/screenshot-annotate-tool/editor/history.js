// editor/history.js — 直近20枚の一覧
(async function () {
  const grid = document.getElementById("grid");
  const empty = document.getElementById("empty");

  function fmt(ts) {
    const d = new Date(ts);
    const p = (n) => String(n).padStart(2, "0");
    return `${d.getMonth() + 1}/${d.getDate()} ${p(d.getHours())}:${p(d.getMinutes())}`;
  }

  async function render() {
    const list = await HistoryDB.list();
    grid.textContent = "";
    empty.hidden = list.length > 0;
    for (const e of list) {
      const card = document.createElement("div");
      card.className = "card";
      card.title = e.url || "";

      const thumb = document.createElement("div");
      thumb.className = "thumb";
      if (e.thumb) thumb.style.backgroundImage = `url("${e.thumb}")`;

      const info = document.createElement("div");
      info.className = "info";
      const text = document.createElement("div");
      text.className = "text";
      const title = document.createElement("div");
      title.className = "title";
      title.textContent = e.title || "（タイトルなし）";
      const sub = document.createElement("div");
      sub.className = "sub";
      sub.textContent = `${fmt(e.updatedAt)}　${e.w} × ${e.h}px`;
      text.append(title, sub);

      const del = document.createElement("button");
      del.className = "del";
      del.textContent = "削除";
      del.onclick = async (ev) => {
        ev.stopPropagation();
        if (!confirm("この履歴を削除しますか？（ダウンロード済みのファイルは消えません）")) return;
        await HistoryDB.remove(e.id);
        render();
      };

      info.append(text, del);
      card.append(thumb, info);
      card.onclick = () => {
        location.href = "editor.html?h=" + encodeURIComponent(e.id);
      };
      grid.appendChild(card);
    }
  }

  render();
})();
