// editor/pdf.js — 依存ライブラリなしで JPEG 1枚をPDF化（DCTDecode 埋め込み）
// buildImagePdf(jpegBytes: Uint8Array, w: number, h: number) -> Blob
// 縦長のページ全体スクショでも開けるよう、ページ寸法は PDF の上限(14400pt)に収める
function buildImagePdf(jpeg, w, h) {
  const PDF_MAX = 14400;
  const s = Math.min(1, PDF_MAX / Math.max(w, h));
  const pw = +(w * s).toFixed(2);
  const ph = +(h * s).toFixed(2);
  const enc = new TextEncoder();
  const chunks = [];
  let length = 0;
  const offsets = [0, 0, 0, 0, 0, 0]; // offsets[n] = "N 0 obj" の開始バイト

  function out(data) {
    const bytes = data instanceof Uint8Array ? data : enc.encode(data);
    chunks.push(bytes);
    length += bytes.length;
  }
  function objStart(n) {
    offsets[n] = length;
  }

  out("%PDF-1.4\n");
  out(new Uint8Array([0x25, 0xe2, 0xe3, 0xcf, 0xd3, 0x0a])); // バイナリ宣言コメント

  objStart(1);
  out("1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n");

  objStart(2);
  out("2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n");

  objStart(3);
  out(
    `3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pw} ${ph}] ` +
      `/Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>\nendobj\n`
  );

  objStart(4);
  out(
    `4 0 obj\n<< /Type /XObject /Subtype /Image /Width ${w} /Height ${h} ` +
      `/ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode ` +
      `/Length ${jpeg.length} >>\nstream\n`
  );
  out(jpeg);
  out("\nendstream\nendobj\n");

  const content = `q\n${pw} 0 0 ${ph} 0 0 cm\n/Im0 Do\nQ\n`;
  const contentBytes = enc.encode(content);
  objStart(5);
  out(`5 0 obj\n<< /Length ${contentBytes.length} >>\nstream\n`);
  out(contentBytes);
  out("\nendstream\nendobj\n");

  const xrefStart = length;
  let xref = "xref\n0 6\n0000000000 65535 f \n";
  for (let n = 1; n <= 5; n++) {
    xref += String(offsets[n]).padStart(10, "0") + " 00000 n \n";
  }
  out(xref);
  out(`trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n${xrefStart}\n%%EOF\n`);

  return new Blob(chunks, { type: "application/pdf" });
}
