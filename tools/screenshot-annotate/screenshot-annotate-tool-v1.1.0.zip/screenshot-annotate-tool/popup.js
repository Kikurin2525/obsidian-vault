// popup.js — ポップアップのボタンから background へキャプチャ要求
document.querySelectorAll("button[data-mode]").forEach((btn) => {
  btn.addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "POPUP_CAPTURE", mode: btn.dataset.mode });
    window.close();
  });
});

// いま割り当てられているショートカットを表示
chrome.commands.getAll((cmds) => {
  const map = {};
  cmds.forEach((c) => (map[c.name] = c.shortcut));
  document.querySelectorAll("button[data-cmd]").forEach((btn) => {
    const keys = btn.querySelector(".keys");
    const sc = map[btn.dataset.cmd];
    keys.textContent = sc || "未設定";
    keys.classList.toggle("none", !sc);
  });
});

document.getElementById("history").onclick = () => {
  chrome.tabs.create({ url: chrome.runtime.getURL("editor/history.html") });
  window.close();
};

document.getElementById("shortcuts").onclick = () => {
  chrome.tabs.create({ url: "chrome://extensions/shortcuts" });
  window.close();
};
