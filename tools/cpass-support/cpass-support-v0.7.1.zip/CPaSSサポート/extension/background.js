/* CPaSS申告アシスト — 公式の関税表に問い合わせる係(service worker)
 * 画面(content.js)からのたのみ:
 *   {type:"verify", tariff:"US"|"EU"|"UK", code:"8518402000"}
 *     → その国の公式の表で「申告できる最下層のコードか」と公式の説明文を返す
 *   {type:"search", tariff:"US"|"UK"|"EU", q:"camera"}
 *     → 公式の表の文字検索の候補を返す(答え表にない品物のとき)
 * 買い手の情報(名前・住所)はここに来ない。送るのはコードと品物の言葉だけ。
 */
"use strict";

const TTL_MS = 7 * 24 * 3600 * 1000; // 1週間は覚えておく(表の改正に追いつけるように短め)

async function cached(key, fn) {
  const now = Date.now();
  const got = await chrome.storage.local.get(key);
  const hit = got[key];
  if (hit && now - hit.at < TTL_MS) return { ...hit.v, cached: true };
  const v = await fn();
  if (v && v.ok !== undefined && !v.networkError) await chrome.storage.local.set({ [key]: { at: now, v } });
  return v;
}

// つながらない(通信・相手のサーバーの不調)ときだけ network 印を付ける。形が変わった等はふつうの失敗(=入れない)
async function getJSON(url) {
  let r;
  try {
    const ctl = new AbortController(); const tm = setTimeout(() => ctl.abort(), 15000);
    r = await fetch(url, { headers: { Accept: "application/json" }, signal: ctl.signal });
    clearTimeout(tm);
  } catch (e) { const er = new Error("つながりません"); er.network = true; throw er; }
  if (r.status === 404) return { status: 404 };
  if (!r.ok) { const er = new Error("HTTP " + r.status); er.network = r.status >= 500 || r.status === 429; throw er; }
  return { status: 200, json: await r.json() };
}

// 米国: USITC HTS(公式)
async function verifyUS(code) {
  const d = code.replace(/\D/g, "");
  const dotted = `${d.slice(0, 4)}.${d.slice(4, 6)}.${d.slice(6, 8)}.${d.slice(8, 10)}`;
  const src = `https://hts.usitc.gov/search?query=${encodeURIComponent(dotted)}`;
  const { json } = await getJSON(`https://hts.usitc.gov/reststop/search?keyword=${encodeURIComponent(dotted)}`);
  const row = (json || []).find(x => (x.htsno || "") === dotted);
  // 時計(第91類)は、統計注1の部品の行(末尾10=ムーブメント/20=ケース/30=ベルト/40=電池)が表に行として出ない
  if (!row && d.startsWith("91") && ["10", "20", "30", "40"].includes(d.slice(8))) {
    const d8 = dotted.slice(0, 10);
    const r8 = (await getJSON(`https://hts.usitc.gov/reststop/search?keyword=${encodeURIComponent(d8)}`)).json || [];
    const p8 = r8.find(x => (x.htsno || "") === d8);
    if (p8) {
      const part = { "10": "Movement", "20": "Case", "30": "Strap, band or bracelet", "40": "Battery" }[d.slice(8)];
      return { ok: true, code: d, display: dotted, desc: `${p8.description} › (Chapter 91 Statistical Note 1) ${part}`, general: p8.general, source: src };
    }
  }
  if (!row) {
    // 10桁の行がなく8桁(統計番号00)で終わる行もある
    return { ok: false, code: d, reason: "USITCの表にこの10桁の行がありません", source: src };
  }
  return { ok: true, code: d, display: dotted, desc: row.description, general: row.general, source: src };
}

// 英国 / EU: 英国政府の Trade Tariff API(EUは北アイルランド用XI=EUのTARICと同じ番号)
async function verifyUKEU(code, tariff) {
  const d = code.replace(/\D/g, "");
  const base = tariff === "EU" ? "https://www.trade-tariff.service.gov.uk/xi" : "https://www.trade-tariff.service.gov.uk";
  const human = tariff === "EU"
    ? `https://ec.europa.eu/taxation_customs/dds2/taric/measures.jsp?Lang=en&Taric=${d}`
    : `https://www.trade-tariff.service.gov.uk/commodities/${d}`;
  const res = await getJSON(`${base}/api/v2/commodities/${d}`);
  if (res.status === 404) return { ok: false, code: d, reason: "公式の表で申告できる最下層のコードではありません", source: human };
  const a = res.json.data.attributes;
  // 見出し(4桁) › … › この行。類(2桁)の長い文は省く
  const path = (res.json.included || [])
    .filter(x => ["heading", "commodity"].includes(x.type))
    .map(x => (x.attributes.description || "").replace(/\s+/g, " ").trim())
    .filter(Boolean);
  if (a.description) path.push(String(a.description).replace(/\s+/g, " ").trim());
  return { ok: !!a.declarable, code: d, display: d, desc: a.description, path, source: human };
}

async function verify(tariff, code) {
  const d = String(code || "").replace(/\D/g, "");
  if (d.length !== 10) return { ok: false, code: d, reason: "10桁ではありません" };
  const key = `v:${tariff}:${d}`;
  try {
    return await cached(key, () => tariff === "US" ? verifyUS(d) : verifyUKEU(d, tariff));
  } catch (e) {
    return e && e.network
      ? { ok: false, code: d, networkError: true, reason: "公式の表につながりませんでした(" + e.message + ")" }
      : { ok: false, code: d, reason: "公式の表の答えが読めませんでした(" + (e && e.message) + ")" };
  }
}

// 公式の説明文の飾り(<br>など)を外して、長すぎるものは切る
function cleanDesc(t) {
  return String(t || "").replace(/<br\s*\/?>/gi, " / ").replace(/<[^>]+>/g, "").replace(/\s+/g, " ").replace(/^ \/ | \/ $/g, "").trim().slice(0, 160);
}

async function search(tariff, q) {
  const key = `s:${tariff}:${q.toLowerCase()}`;
  try {
    return await cached(key, async () => {
      if (tariff === "US") {
        const { json } = await getJSON(`https://hts.usitc.gov/reststop/search?keyword=${encodeURIComponent(q)}`);
        const rows = (json || []).filter(x => /^\d{4}\.\d{2}\.\d{2}\.\d{2}$/.test(x.htsno || ""));
        return { ok: true, items: rows.slice(0, 15).map(x => ({ code: x.htsno.replace(/\D/g, ""), desc: cleanDesc(x.description) })) };
      }
      const base = tariff === "EU" ? "https://www.trade-tariff.service.gov.uk/xi" : "https://www.trade-tariff.service.gov.uk";
      const { json } = await getJSON(`${base}/api/v2/search?q=${encodeURIComponent(q)}`);
      const at = json.data.attributes;
      // ぴったりの見出しが見つかったとき: その見出しの「申告できる最下層」を全部出す
      if (at.type === "exact_match" && at.entry) {
        const id = String(at.entry.id);
        if (at.entry.endpoint === "commodities") return { ok: true, items: [{ code: id, desc: "" }] };
        const h = await getJSON(`${base}/api/v2/headings/${id.slice(0, 4)}`);
        const items = (h.json?.included || [])
          .filter(x => x.attributes?.leaf && x.attributes.goods_nomenclature_item_id)
          .map(x => ({ code: x.attributes.goods_nomenclature_item_id, desc: cleanDesc(x.attributes.description) }));
        return { ok: true, items: items.slice(0, 25) };
      }
      const g = (at.goods_nomenclature_match || {});
      let items = (g.commodities || []).map(x => x._source || x)
        .filter(s => s.declarable !== false)
        .slice(0, 15)
        .map(s => ({ code: s.goods_nomenclature_item_id, desc: cleanDesc(s.description) }));
      if (!items.length) {
        // 品名の索引(reference_match)で見出しが見つかったとき: その見出しの「申告できる最下層」を出す
        const ref = at.reference_match || {};
        const hit = [...(ref.commodities || []), ...(ref.subheadings || []), ...(ref.headings || [])]
          .map(x => (x._source || x).reference || {}).find(r => r.goods_nomenclature_item_id);
        if (hit) {
          const h = await getJSON(`${base}/api/v2/headings/${String(hit.goods_nomenclature_item_id).slice(0, 4)}`);
          items = (h.json?.included || [])
            .filter(x => x.attributes?.leaf && x.attributes.goods_nomenclature_item_id)
            .map(x => ({ code: x.attributes.goods_nomenclature_item_id, desc: cleanDesc(x.attributes.description) }))
            .slice(0, 25);
        }
      }
      return { ok: true, items };
    });
  } catch (e) {
    return { ok: false, networkError: true, items: [], reason: e.message };
  }
}

chrome.runtime.onMessage.addListener((msg, _sender, send) => {
  (async () => {
    if (msg.type === "verify") return send(await verify(msg.tariff, msg.code));
    if (msg.type === "search") return send(await search(msg.tariff, msg.q));
    if (msg.type === "openOptions") { chrome.runtime.openOptionsPage(); return send({ ok: true }); }
    send({ ok: false, reason: "unknown" });
  })();
  return true; // 非同期で返す
});
