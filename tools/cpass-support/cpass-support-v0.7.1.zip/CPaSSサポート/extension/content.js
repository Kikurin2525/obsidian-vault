/* CPaSSサポート — CPaSSの「詳細」画面に入れる係
 * 人が「発送手続き → 編集」で詳細画面を開く → 品物の行ごとに [CPaSSサポート] ボタンを出す
 * 押す → 品物を見分ける → 届け先の国の公式の表で番号を確かめる → 下書きを見せる → [この内容で入れる]
 * 「保存する」は押さない(最後は人の目)。買い手の名前・住所は読まない(国は国旗の画像から)。
 */
(function () {
  "use strict";
  const E = self.CPA_ENGINE;
  const STAMP_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/></svg>'; // Lucide circle-check (ISC)
  const TARIFF_LABEL = { US: "米国 HTSUS(USITC)", EU: "EU TARIC", UK: "英国 UK Tariff", OTHER: "国際共通 HS(6桁)" };

  let CATS = null;
  async function categories() {
    if (CATS) return CATS;
    try { CATS = await (await fetch(chrome.runtime.getURL("data/categories.json"))).json(); } catch (e) { CATS = { sites: {} }; }
    return CATS;
  }

  let MASTER = null;
  async function master() {
    if (MASTER) return MASTER;
    const url = chrome.runtime.getURL("data/master.json");
    MASTER = await (await fetch(url)).json();
    return MASTER;
  }

  const send = (msg) => new Promise((res) => {
    try { chrome.runtime.sendMessage(msg, (r) => res(r || { ok: false, reason: "no response" })); }
    catch (e) { res({ ok: false, reason: e.message }); }
  });
  const store = {
    async get(k) { const g = await chrome.storage.local.get(k); return g[k]; },
    async set(k, v) { await chrome.storage.local.set({ [k]: v }); },
  };

  // ---- 画面から読む -------------------------------------------------------
  function findTitleCell(root, label) {
    return [...root.querySelectorAll("td")].find(td => {
      const t = td.querySelector(":scope > .title, :scope > div > .title");
      return t && t.textContent.replace(/\s+/g, "").startsWith(label);
    });
  }

  /** 詳細画面の中の、品物ごとのまとまり(2行で1品) */
  function itemBlocks(modal) {
    const out = [];
    for (const titleBox of modal.querySelectorAll(".item_title")) {
      const tr1 = titleBox.closest("tr");
      const tr2 = tr1 && tr1.nextElementSibling;
      if (!tr2) continue;
      const nameCell = findTitleCell(tr2, "告知のための商品名");
      const hsCell = findTitleCell(tr2, "HSコード") || tr2.querySelector(".hs_code")?.closest("td");
      if (!nameCell || !hsCell) continue;
      const a = titleBox.querySelector(".value a");
      const idText = titleBox.querySelector(".itemid")?.textContent || "";
      out.push({
        tr1, tr2, nameCell, hsCell,
        title: (a?.textContent || "").trim(),
        itemId: (idText.match(/\d{9,}/) || [""])[0],
        nameInput: nameCell.querySelector("input"),
        hsInput: hsCell.querySelector(".hs_code input") || hsCell.querySelector("input"),
        skuInput: findTitleCell(tr2, "SKU")?.querySelector("input"),
      });
    }
    return out;
  }

  /** 届け先の国: 国旗の画像(…/it.svg)→ ISO。だめなら「配送先住所」の国名の行だけ見る */
  function destination(modal) {
    const flag = modal.querySelector("img.recipient_country_flag");
    const m = flag && (flag.getAttribute("src") || "").match(/([a-z]{2})\.svg(\?|$)/i);
    if (m) return m[1].toUpperCase().replace("UK", "GB");
    for (const li of modal.querySelectorAll(".address_cntlr li")) {
      const iso = E.countryExact(li.textContent);
      if (iso) return iso;
    }
    return null;
  }

  // ---- 入れる(Reactの入力欄に、人が打ったのと同じ形で) ---------------------
  // CPaSSは1つの欄を変えると表を描き直すことがある → 入れるたびに欄を探し直し、入ったかを確かめる
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));

  function setReactValue(input, value) {
    if (!input) return false;
    const proto = Object.getPrototypeOf(input);
    const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set
      || Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
    input.focus();
    setter.call(input, value);
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
    input.blur();
    return input.value === value;
  }

  // 2回目からは、ブラウザに「打ち込み」として入れてもらう(人がキーで打つのと同じ届き方)
  function typeLikeHuman(input, value) {
    input.focus();
    input.select();
    let ok = false;
    try { ok = document.execCommand("insertText", false, value); } catch (e) { ok = false; }
    if (!ok) return setReactValue(input, value);
    input.blur();
    return true;
  }

  // ページの中(main_world.js)に頼んで、CPaSS自身の onChange で入れてもらう
  let fillSeq = 0;
  const lastDiag = {};
  function fillViaPage(input, kind, value) {
    return new Promise((resolve) => {
      const id = "f" + Date.now() + "_" + (++fillSeq);
      input.setAttribute("data-cpa-fill", id);
      const done = (r) => { document.removeEventListener("cpa:filled", on); input.removeAttribute("data-cpa-fill"); resolve(r); };
      const on = (ev) => { let r; try { r = JSON.parse(ev.detail); } catch (e) { return; } if (r.id === id) { lastDiag[kind] = r; done(r); } };
      document.addEventListener("cpa:filled", on);
      document.dispatchEvent(new CustomEvent("cpa:fill", { detail: JSON.stringify({ id, kind, value }) }));
      setTimeout(() => done({ ok: false, err: "ページの中の係から返事がない" }), 800);
    });
  }

  // その品物のeBayカテゴリ番号を、ページの中の係に聞く(CPaSSが持っている番号。eBayのページは読まない)
  function pageCategory(input, itemId) {
    return new Promise((resolve) => {
      if (!input) return resolve(null);
      const id = "i" + Date.now() + "_" + (++fillSeq);
      input.setAttribute("data-cpa-fill", id);
      const done = (r) => { document.removeEventListener("cpa:info-result", on); input.removeAttribute("data-cpa-fill"); resolve(r); };
      const on = (ev) => { let r; try { r = JSON.parse(ev.detail); } catch (e) { return; } if (r.id === id) done(r); };
      document.addEventListener("cpa:info-result", on);
      document.dispatchEvent(new CustomEvent("cpa:info", { detail: JSON.stringify({ id, itemId }) }));
      setTimeout(() => done(null), 800);
    });
  }

  async function fillOne(getInput, value, kind) {
    for (let i = 0; i < 4; i++) {
      const inp = getInput();
      if (!inp) { await sleep(250); continue; }
      if (inp.value === value) return true;
      if (i === 0) await fillViaPage(inp, kind, value);
      else if (i === 1) setReactValue(inp, value);
      else typeLikeHuman(inp, value);
      await sleep(350);
      const now = getInput();
      if (now && now.value === value) return true;
    }
    return false;
  }

  // ---- パネル ---------------------------------------------------------------
  function el(tag, cls, html) { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; }
  function esc(s) { return String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])); }

  function closePanels() { document.querySelectorAll(".cpa-host").forEach(p => p.remove()); }

  let PANEL_GEN = 0;
  async function openPanel(block, modal) {
    const gen = ++PANEL_GEN;
    closePanels();
    const types = (await master()).types;
    await categories();
    if (gen !== PANEL_GEN) return; // そのあいだに別のパネルを開いた
    const iso = destination(modal);
    const tariff = E.tariffFor(iso);
    const panel = el("div", "cpa-panel");
    panel.setAttribute("role", "dialog");
    panel.setAttribute("aria-label", "CPaSSサポート");
    const host = el("tr", "cpa-host"); const td = el("td"); td.colSpan = 9; td.appendChild(panel); host.appendChild(td);
    block.tr2.after(host);

    // 入れる直前に、同じ品物の欄を探し直す(表が描き直されても空振りしない)
    // 同じ品物(アイテム番号とタイトルが一致)だけ。1つに決められなければ入れない(別の品物に入れない)
    const fresh = () => {
      const all = itemBlocks(document);
      const same = (b) => b.itemId === block.itemId && b.title === block.title;
      const byDom = all.find(b => b.tr1 === block.tr1 && b.tr1.isConnected && same(b));
      if (byDom) return byDom;
      const m = all.filter(same);
      return m.length === 1 ? m[0] : null;
    };

    const state = { type: null, option: 0, axes: {}, axesTouched: false, pick: null, name: "", code: null, source: "dict", moreOpen: false, nameEdited: false };
    const choose = (t, pick) => {
      state.pick = pick;
      state.option = pick.index;
      state.axes = { ...((t.variants[pick.index] || {}).axes_ja || {}) };
      state.axesTouched = false;
    };

    // 前に決めた品物(この人のブラウザだけに保存)
    const learned = (block.itemId && await store.get("learn:item:" + block.itemId))
      || (block.skuInput?.value && await store.get("learn:sku:" + block.skuInput.value));
    const cands = E.classify(block.title, types);

    // eBayのカテゴリ(出品のときに選んだもの)→ 品物の種類。タイトルより確かなので先に使う
    const sites = (await categories()).sites || {};
    const info = await pageCategory(block.nameInput, block.itemId);
    if (gen !== PANEL_GEN) return;
    let catHit = null;
    if (info && info.ok) {
      // CPaSSのサイト番号はeBayのと違うことがある(例: 6)。その番号 → 米国 → Motors → 英語のサイト の順に探す
      const order = [...new Set([info.site, "0", "100", "2", "3", "15"].filter(x => x != null))];
      for (const sid of order) { const h = sites[sid] && sites[sid][info.cat]; if (h) { catHit = h; break; } }
    }
    state.catInfo = info; state.catHit = catHit;
    const hintText = block.title + (catHit ? " " + catHit.n : "");

    // 覚えた種類は「人が選び直したとき」のものだけ使う(自動の見まちがいを覚えて繰り返さない)
    if (learned && learned.manual && types.find(t => t.id === learned.typeId)) {
      state.type = types.find(t => t.id === learned.typeId); state.source = "learned";
    } else if (catHit) {
      const inCat = cands.filter(c => catHit.t.includes(c.id));
      state.type = types.find(t => t.id === (inCat[0] ? inCat[0].id : catHit.t[0])) || null;
      state.source = "category";
    } else if (cands.length) {
      state.type = types.find(t => t.id === cands[0].id);
    }
    if (state.type) choose(state.type, E.pickVariant(state.type, hintText));

    let renderGen = 0;
    async function render() {
      const rgen = ++renderGen;
      const alive = () => rgen === renderGen && gen === PANEL_GEN && host.isConnected;
      const t = state.type;
      panel.innerHTML = "";

      // 見出し
      const head = el("div", "cpa-head");
      head.innerHTML = `<div class="cpa-brand"><span class="cpa-mark">${STAMP_SVG}</span>CPaSSサポート</div>
        <div class="cpa-dest">${iso ? `届け先 <b>${esc(iso)}</b> → ${esc(TARIFF_LABEL[tariff])}` : "届け先の国が読めません"}</div>
        <button class="cpa-x" aria-label="閉じる">×</button>`;
      head.querySelector(".cpa-x").onclick = () => host.remove();
      panel.appendChild(head);

      // 品物の種類
      const typeRow = el("div", "cpa-row");
      typeRow.appendChild(el("div", "cpa-label", "品物"));
      const sel = el("select", "cpa-select");
      const opts = [...new Set([...(state.type ? [state.type.id] : []), ...(state.catHit ? state.catHit.t : []), ...cands.map(c => c.id)])];
      sel.appendChild(new Option("— 種類を選ぶ(一覧から) —", ""));
      for (const id of opts) { const ty = types.find(x => x.id === id); if (ty) sel.appendChild(new Option("★ " + ty.name_ja, id)); }
      const all = [...types].sort((a, b) => a.name_ja.localeCompare(b.name_ja, "ja"));
      const og = document.createElement("optgroup"); og.label = "すべての種類";
      for (const ty of all) og.appendChild(new Option(ty.name_ja, ty.id));
      sel.appendChild(og);
      sel.value = state.type?.id || "";
      sel.onchange = () => {
        state.type = types.find(x => x.id === sel.value) || null;
        state.picked = null; state.nameEdited = false; state.source = "manual"; state.moreOpen = false;
        if (state.type) choose(state.type, E.pickVariant(state.type, hintText));
        render();
      };
      typeRow.appendChild(sel);
      const why = el("div", "cpa-why",
        state.source === "learned" ? "前にこの品物で決めた種類です"
          : state.source === "category" ? `eBayのカテゴリ「${esc(state.catHit.n)}」から見分けました`
          : (cands[0] && state.type?.id === cands[0].id ? `タイトルの「${esc(cands[0].hits.slice(0, 3).join("・"))}」から見分けました` : (state.type ? "" : "タイトルから見分けられませんでした。一覧から選んでください")));
      typeRow.appendChild(why);
      panel.appendChild(typeRow);

      const pickLine = () => {
        if (!t || t.variants.length < 2 || state.option < 0) return "";
        const v = t.variants[state.option];
        const why = state.pick?.why === "title" ? `「${esc(state.pick.label || "")}」から` : "いちばんよくある形";
        return `<div class="cpa-pick">見分け: ${esc(v.option_ja || v.option || "")}<span>(${why})</span></div>`;
      };
      const c = t && state.option >= 0 ? E.codeFor(t, tariff, state.option) : null;
      state.code = c;
      if (t && !state.nameEdited) {
        const vv = state.option >= 0 ? t.variants[state.option] : null;
        state.name = E.declaredName((vv && vv.declared_name) || t.declared_name, block.title);
      } else if (!t && !state.nameEdited) {
        state.name = block.nameInput?.value || "";
      }

      // 告知のための商品名
      const nameRow = el("div", "cpa-row");
      nameRow.appendChild(el("div", "cpa-label", "商品名(英語)"));
      const nameIn = el("input", "cpa-input"); nameIn.maxLength = 128; nameIn.value = state.name;
      const cnt = el("div", "cpa-count");
      const warn = el("div", "cpa-warn");
      const upd = () => {
        cnt.textContent = `${nameIn.value.length} / 128`;
        warn.textContent = E.isVague(nameIn.value) ? "⛔ これだけでは税関が受け付けません(何か・素材や機能まで書く)" : "";
        state.name = nameIn.value;
      };
      nameIn.oninput = () => { state.nameEdited = true; upd(); }; upd();
      nameRow.append(nameIn, cnt, warn);
      panel.appendChild(nameRow);

      // HSコード
      const codeRow = el("div", "cpa-row");
      codeRow.appendChild(el("div", "cpa-label", "HSコード"));
      const codeBox = el("div", "cpa-code");
      codeRow.appendChild(codeBox);
      panel.appendChild(codeRow);

      // ボタン
      const foot = el("div", "cpa-foot");
      const go = el("button", "cpa-go", "この内容で入れる");
      go.type = "button";
      const note = el("div", "cpa-note", "入れたあと、画面の「保存する」はご自身で押してください。");
      foot.append(note, go);
      panel.appendChild(foot);

      if (!tariff) {
        codeBox.innerHTML = `<div class="cpa-status bad">⛔ 届け先の国が読めません。番号はCPaSSの🧭で選んでください。</div>`;
        go.disabled = true;
      } else if (!t && state.picked) {
        codeBox.innerHTML = `<div class="cpa-num">${esc(state.picked.code)}<span class="cpa-stamp">${STAMP_SVG}公式の表から選択</span></div>
          <div class="cpa-path">${esc(state.picked.desc || "")}</div>`;
        state.code = { code: state.picked.code };
      } else if (t && !c && state.option < 0) {
        codeBox.innerHTML = `<div class="cpa-status warn">🟡 上の質問に答えると、番号を公式の表で確かめます</div>`;
        go.disabled = true;
      } else if (t && !c) {
        codeBox.innerHTML = `<div class="cpa-status bad">⛔ この国の番号が答え表で確認できていません。CPaSSの🧭で選んでください。</div>`;
        go.disabled = true;
      } else if (!t || !c) {
        // 答え表にない品物: 届け先の国の公式の表を、言葉で探して選ぶ
        const tf = tariff === "OTHER" ? "UK" : tariff;
        codeBox.innerHTML = `<div class="cpa-status warn">🟡 答え表にない品物です。届け先の国の公式の表を英語で探して、いちばん合う行を選んでください。</div>
          <div class="cpa-search"><input class="cpa-input" placeholder="例: digital camera / wrist watch / fishing reel"><button class="cpa-chip" type="button">公式の表で探す</button></div>
          <div class="cpa-results"></div>`;
        const qIn = codeBox.querySelector(".cpa-search input");
        const qBtn = codeBox.querySelector(".cpa-search button");
        const resBox = codeBox.querySelector(".cpa-results");
        const run = async () => {
          if (!qIn.value.trim()) return;
          resBox.textContent = "探しています…";
          const r = await send({ type: "search", tariff: tf, q: qIn.value.trim() });
          resBox.innerHTML = "";
          if (!r.ok || !r.items.length) { resBox.textContent = "見つかりませんでした。別の言葉で試してください。"; return; }
          for (const it of r.items) {
            const b = el("button", "cpa-result", `<span class="cpa-rcode">${esc(it.code)}</span><span>${esc(it.desc || "")}</span>`);
            b.type = "button";
            b.onclick = async () => {
              const v = await send({ type: "verify", tariff: tf, code: it.code });
              if (!v.ok) { b.classList.add("bad"); b.title = v.reason || ""; return; }
              // その他の国は、英国の表で探した行の先頭6桁(国際共通)だけを使う
              state.picked = { code: tariff === "OTHER" ? String(v.code).slice(0, 6) : v.code, desc: (v.path && v.path.join(" › ")) || v.desc || it.desc };
              render();
            };
            resBox.appendChild(b);
          }
        };
        qBtn.onclick = run; qIn.onkeydown = (e) => { if (e.key === "Enter") { e.preventDefault(); run(); } };
        go.disabled = true;
      } else if (tariff === "OTHER") {
        codeBox.innerHTML = `<div class="cpa-num">${esc(c.code)}</div>
          <div class="cpa-status warn">🟡 この国は国際共通の6桁を入れます。CPaSSで国の番号を求められたら🧭で選び直してください。</div>`;
      } else {
        codeBox.innerHTML = `<div class="cpa-num">${esc(tariff === "US" ? E.formatUS(c.code) : c.code)}</div><div class="cpa-status">公式の表で確認中…</div>`;
        const v = await send({ type: "verify", tariff, code: c.code });
        if (!alive()) return; // そのあいだに種類を変えた・閉じた
        state.verified = v;
        if (v.ok) {
          const path = (v.path && v.path.length ? v.path.join(" › ") : (c.desc_path || v.desc || ""));
          codeBox.innerHTML = `<div class="cpa-num">${esc(tariff === "US" ? E.formatUS(c.code) : c.code)}<span class="cpa-stamp">${STAMP_SVG}公式で確認ずみ</span></div>
            ${pickLine()}
            <details class="cpa-detail"><summary>公式の表の説明を見る</summary><div class="cpa-path">${esc(path)}</div>
            <a class="cpa-src" href="${esc(v.source)}" target="_blank" rel="noopener">${esc(TARIFF_LABEL[tariff])} で見る ↗</a></details>
            ${(c.component_lines && c.component_lines.length) ? `<div class="cpa-status warn">🟡 米国の時計は、正式には部品ごとの行(${esc(c.component_lines.join(" / "))})に分けて申告する決まりです(HTS第91類 統計注1)。CPaSSの欄は1つなので、本体(ムーブメント)の行を入れます。高額品は通関業者にご確認ください。</div>` : ""}`;
        } else {
          codeBox.innerHTML = `<div class="cpa-num">${esc(c.code)}</div><div class="cpa-status bad">⛔ ${esc(v.reason || "公式の表で確認できませんでした")}。入れません。</div>`;
          go.disabled = true;
          if (v.networkError) {
            // つながらないだけのとき: 答え表の番号(作ったときに公式で確認ずみ)を、別のボタンで入れられる
            note.textContent = `公式の表に今つながりません。番号は答え表のもの(${c.verified || "確認日不明"}に公式で確認)です。`;
            const anyway = el("button", "cpa-more-btn", "番号を確かめずに入れる");
            anyway.type = "button";
            anyway.onclick = () => { go.disabled = false; go.click(); };
            note.appendChild(anyway);
          }
        }
      }
      if (!go.disabled) go.focus({ preventScroll: true }); // Enterでも入れられる

      go.onclick = async () => {
        // 押した時点の内容で固定する(途中で種類を変えても混ざらない)
        const snap = { name: state.name, code: state.code ? state.code.code : "", typeId: state.type ? state.type.id : null, option: state.option, manual: state.source === "manual" || (state.source === "learned") };
        if (!snap.name.trim() || E.isVague(snap.name)) {
          note.textContent = "⛔ 商品名が税関で受け付けられない書き方です。何か・素材や機能まで英語で書いてください。";
          return;
        }
        if (!fresh()) { note.textContent = "⛔ この品物の欄を1つに決められませんでした。画面を閉じて開き直してください。"; return; }
        go.disabled = true; go.textContent = "入れています…";
        panel.classList.add("cpa-busy");
        const codeToFill = snap.code;
        state.name = snap.name;
        const okName = await fillOne(() => fresh()?.nameInput, snap.name, "name");
        const okCode = codeToFill ? await fillOne(() => fresh()?.hsInput, codeToFill, "hs") : true;
        await sleep(300);
        // もう片方が描き直しで戻っていないか、最後にもう一度見る
        const fb = fresh();
        const nameOk = okName && fb?.nameInput?.value === snap.name;
        const codeOk = okCode && (!codeToFill || fb?.hsInput?.value === codeToFill);
        if (!nameOk && fb?.nameInput) await fillOne(() => fresh()?.nameInput, snap.name, "name");
        if (!codeOk && codeToFill && fb?.hsInput) await fillOne(() => fresh()?.hsInput, codeToFill, "hs");
        const fb2 = fresh();
        const finalName = fb2?.nameInput?.value === snap.name;
        const finalCode = !codeToFill || fb2?.hsInput?.value === codeToFill;
        panel.classList.remove("cpa-busy");
        if (finalName && finalCode) {
          if (snap.typeId && snap.manual) { // 人が選び直した種類を、入ったときだけ覚える
            const rec = { typeId: snap.typeId, option: snap.option, manual: true, at: Date.now() };
            if (block.itemId) await store.set("learn:item:" + block.itemId, rec);
            if (block.skuInput?.value) await store.set("learn:sku:" + block.skuInput.value, rec);
          }
          go.textContent = "入れました ✓"; go.classList.add("done");
          setTimeout(() => host.remove(), 1400);
        } else {
          go.disabled = false; go.classList.add("bad");
          go.textContent = "もう一度入れる";
          note.innerHTML = `⛔ ${!finalCode ? "HSコード" : "商品名"}の欄に入りませんでした。番号 <b class="cpa-copy">${esc(codeToFill)}</b> を手で入れてください(押すとコピー)。`;
          const cp = note.querySelector(".cpa-copy");
          if (cp) cp.onclick = () => navigator.clipboard?.writeText(codeToFill);
          const dg = el("button", "cpa-more-btn", "調べるための情報をコピー");
          dg.type = "button";
          dg.onclick = () => {
            const hsCell = fresh()?.hsCell;
            const info = {
              v: chrome.runtime.getManifest().version, at: new Date().toISOString(),
              diag: lastDiag, want: codeToFill, now: fresh()?.hsInput?.value ?? null,
              hsCell: hsCell ? hsCell.outerHTML.replace(/value="[^"]*"/g, 'value="…"').slice(0, 3000) : null,
            };
            navigator.clipboard?.writeText(JSON.stringify(info, null, 1));
            dg.textContent = "コピーしました ✓";
          };
          note.appendChild(dg);
        }
      };
    }
    await render();
  }

  // ---- 詳細画面を見張って、ボタンを出す -------------------------------------
  function decorate() {
    for (const b of itemBlocks(document)) {
      if (b.nameCell.querySelector(".cpa-btn")) continue;
      // 国旗・住所がある、いちばん近い入れ物(詳細画面)
      let modal = b.tr1.parentElement;
      while (modal && modal !== document.body && !modal.querySelector("img.recipient_country_flag, .address_cntlr")) modal = modal.parentElement;
      modal = modal || document.body;
      const btn = el("button", "cpa-btn", `<span class="cpa-mark">${STAMP_SVG}</span>CPaSSサポート`);
      btn.type = "button";
      btn.title = "告知のための商品名とHSコードを、公式の表で確かめて入れます";
      btn.onclick = (ev) => { ev.preventDefault(); ev.stopPropagation(); openPanel(b, modal); };
      const t = b.nameCell.querySelector(".title");
      (t || b.nameCell).appendChild(btn);
    }
  }
  const mo = new MutationObserver(() => { clearTimeout(decorate._t); decorate._t = setTimeout(decorate, 250); });
  mo.observe(document.documentElement, { childList: true, subtree: true });
  decorate();
})();
