// 覚えている品物の数を出す・忘れる(この人のブラウザの中だけ)
async function count() {
  const all = await chrome.storage.local.get(null);
  return Object.keys(all).filter(k => k.startsWith("learn:item:")).length;
}
(async () => {
  try { document.getElementById("ver").textContent = "非公式 v" + chrome.runtime.getManifest().version; } catch (e) {}
  document.getElementById("n").textContent = await count();
  document.getElementById("clear").onclick = async () => {
    if (!confirm("覚えている品物の種類を、すべて忘れます。よろしいですか?")) return;
    const all = await chrome.storage.local.get(null);
    await chrome.storage.local.remove(Object.keys(all).filter(k => k.startsWith("learn:")));
    document.getElementById("n").textContent = await count();
  };
})();
