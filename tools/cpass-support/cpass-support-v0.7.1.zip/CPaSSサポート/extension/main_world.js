/* CPaSSサポート — ページの中(React)から入れる係(world: MAIN)
 * 拡張のふつうの係(content.js)は、ページのReactの中身に手が届かない。
 * そこでこの係が、CPaSS自身の「欄が変わったときの処理(onChange)」をそのまま呼んで値を入れる。
 * やり取りは document のイベントで、文字(JSON)だけ。買い手の情報は扱わない。
 */
(function () {
  "use strict";
  if (window.__cpaMainWorld) return;
  window.__cpaMainWorld = true;

  const fiberOf = (el) => {
    const k = Object.keys(el).find(k => k.startsWith("__reactFiber$") || k.startsWith("__reactInternalInstance$"));
    return k ? el[k] : null;
  };
  const typeName = (f) => typeof f.type === "string" ? f.type : (f.type && (f.type.displayName || f.type.name || (f.type.render && f.type.render.name))) || "?";

  // 入力欄から上へたどり、欄のまとまり(td)に着くまでで、いちばん外側の onChange = CPaSSが書いた処理
  function outerOnChange(el) {
    let f = fiberOf(el), found = null, chain = [];
    for (let i = 0; f && i < 60; i++, f = f.return) {
      chain.push(typeName(f));
      if (f.type === "td") break;
      const p = f.memoizedProps;
      if (p && typeof p.onChange === "function") found = p;
    }
    return { props: found, chain };
  }

  // その品物のeBayカテゴリ番号とサイト番号だけを探して返す(CPaSSが🧭の候補探しに使っているのと同じ値)。
  // 返すのは2つの番号だけ。名前・住所などほかの値は外に出さない。
  function findCategory(el, itemId) {
    const items = [], cats = [];
    const seen = new WeakSet();
    const scan = (o, depth) => {
      if (!o || typeof o !== "object" || depth > 6 || seen.has(o)) return;
      seen.add(o);
      if (o.$$typeof) return; // Reactの部品そのものは見ない
      if (Array.isArray(o)) { for (const x of o.slice(0, 200)) scan(x, depth + 1); return; }
      if ("ebayCategoryID1" in o) cats.push(o);
      if ("ebayItemID" in o && "salesOrderKey" in o) items.push(o);
      for (const k of Object.keys(o)) { if (k !== "children" && k !== "_owner") scan(o[k], depth + 1); }
    };
    // 目的の品物(アイテム番号が一致)と、その注文のカテゴリが両方見つかるまで上へたどる
    const findItem = () => items.filter(x => String(x.ebayItemID) === String(itemId));
    const findCat = (item) => (item.ebaySalesOrder && item.ebaySalesOrder.ebayCategoryID1 ? item.ebaySalesOrder : null)
      || cats.find(x => x.ebaySalesOrderKey != null && x.ebaySalesOrderKey == item.salesOrderKey);
    let f = fiberOf(el);
    for (let i = 0; f && i < 80; i++, f = f.return) {
      scan(f.memoizedProps, 0);
      const its = findItem();
      if (its.length && its.every(findCat)) break;
    }
    const its = findItem();
    if (!its.length) return { ok: false, err: "この品物が見つからない" };
    const cs = [...new Set(its.map(findCat).filter(Boolean).map(c => String(c.ebayCategoryID1) + "|" + c.ebaySiteID))];
    // 同じアイテム番号でカテゴリが食い違う・見つからないときは使わない(取りちがえ防止)
    if (cs.length !== 1) return { ok: false, err: `カテゴリを1つに決められない(${cs.length})` };
    const c = findCat(its[0]);
    return { ok: true, cat: String(c.ebayCategoryID1), site: c.ebaySiteID != null ? String(c.ebaySiteID) : null };
  }

  document.addEventListener("cpa:info", (ev) => {
    let req; try { req = JSON.parse(ev.detail); } catch (e) { return; }
    let res;
    try {
      const el = document.querySelector(`[data-cpa-fill="${CSS.escape(req.id)}"]`);
      res = el ? findCategory(el, req.itemId) : { ok: false, err: "欄が見つからない" };
    } catch (e) { res = { ok: false, err: String(e && e.message || e) }; }
    res.id = req.id;
    document.dispatchEvent(new CustomEvent("cpa:info-result", { detail: JSON.stringify(res) }));
  });

  document.addEventListener("cpa:fill", (ev) => {
    let req;
    try { req = JSON.parse(ev.detail); } catch (e) { return; }
    const res = { id: req.id, ok: false };
    try {
      const el = document.querySelector(`[data-cpa-fill="${CSS.escape(req.id)}"]`);
      if (!el) throw new Error("欄が見つからない");
      const { props, chain } = outerOnChange(el);
      res.chain = chain.slice(0, 25);
      if (!props) throw new Error("onChangeが見つからない");
      if (req.kind === "hs") {
        props.onChange(req.value, { value: req.value, label: req.value });
      } else {
        const fake = { target: { value: req.value }, currentTarget: { value: req.value }, persist() {}, preventDefault() {}, stopPropagation() {}, type: "change" };
        props.onChange(fake);
      }
      res.ok = true;
    } catch (e) {
      res.err = String(e && e.message || e);
    }
    document.dispatchEvent(new CustomEvent("cpa:filled", { detail: JSON.stringify(res) }));
  });
})();
