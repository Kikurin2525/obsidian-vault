/* CPaSS申告アシスト — 見分けのエンジン(画面に依存しない部分)
 * - 国 → 使う関税表(US / EU / UK / その他)
 * - タイトル → 品物の種類(答え表 data/master.json のキーワード)
 * - 告知用の商品名を組み立てる(ICS2・CBPで受け付けられない言葉をはじく)
 * Node でもブラウザでも動くように、グローバル CPA_ENGINE に出す。
 */
(function (root) {
  "use strict";

  // EU加盟27か国(ISO 3166-1 alpha-2)。EUはTARIC(10桁)を共通で使う。
  const EU = new Set("AT BE BG HR CY CZ DK EE FI FR DE GR IE IT LV LT LU MT NL PL PT RO SK SI ES SE".split(" "));

  // CPaSSの画面に出る国名(英語・日本語) → ISOコード。画面は英語の国名(例: Italy / United States)。
  const COUNTRY_NAMES = {
    "united states": "US", "usa": "US", "アメリカ": "US", "米国": "US", "アメリカ合衆国": "US",
    "united kingdom": "GB", "great britain": "GB", "uk": "GB", "イギリス": "GB", "英国": "GB",
    "austria": "AT", "belgium": "BE", "bulgaria": "BG", "croatia": "HR", "cyprus": "CY",
    "czech republic": "CZ", "czechia": "CZ", "denmark": "DK", "estonia": "EE", "finland": "FI",
    "france": "FR", "germany": "DE", "greece": "GR", "ireland": "IE", "italy": "IT",
    "latvia": "LV", "lithuania": "LT", "luxembourg": "LU", "malta": "MT", "netherlands": "NL",
    "poland": "PL", "portugal": "PT", "romania": "RO", "slovakia": "SK", "slovenia": "SI",
    "spain": "ES", "sweden": "SE",
    "オーストリア": "AT", "ベルギー": "BE", "ブルガリア": "BG", "クロアチア": "HR", "キプロス": "CY",
    "チェコ": "CZ", "デンマーク": "DK", "エストニア": "EE", "フィンランド": "FI", "フランス": "FR",
    "ドイツ": "DE", "ギリシャ": "GR", "アイルランド": "IE", "イタリア": "IT", "ラトビア": "LV",
    "リトアニア": "LT", "ルクセンブルク": "LU", "マルタ": "MT", "オランダ": "NL", "ポーランド": "PL",
    "ポルトガル": "PT", "ルーマニア": "RO", "スロバキア": "SK", "スロベニア": "SI", "スペイン": "ES",
    "スウェーデン": "SE",
    "canada": "CA", "カナダ": "CA", "australia": "AU", "オーストラリア": "AU",
    "new zealand": "NZ", "ニュージーランド": "NZ", "switzerland": "CH", "スイス": "CH",
    "norway": "NO", "ノルウェー": "NO", "israel": "IL", "イスラエル": "IL", "mexico": "MX", "メキシコ": "MX",
    "singapore": "SG", "シンガポール": "SG", "hong kong": "HK", "香港": "HK", "taiwan": "TW", "台湾": "TW",
    "korea, republic of": "KR", "south korea": "KR", "韓国": "KR", "china": "CN", "中国": "CN",
    "thailand": "TH", "タイ": "TH", "philippines": "PH", "フィリピン": "PH", "malaysia": "MY", "マレーシア": "MY",
    "brazil": "BR", "ブラジル": "BR", "saudi arabia": "SA", "サウジアラビア": "SA",
    "united arab emirates": "AE", "アラブ首長国連邦": "AE", "south africa": "ZA", "南アフリカ": "ZA",
  };

  function countryToIso(text) {
    if (!text) return null;
    const t = String(text).trim().toLowerCase();
    if (COUNTRY_NAMES[t]) return COUNTRY_NAMES[t];
    // 住所の行の中から国名を探す(長い名前から先に当てる)
    const names = Object.keys(COUNTRY_NAMES).sort((a, b) => b.length - a.length);
    for (const n of names) {
      if (n.length < 3) continue;
      const re = new RegExp("(^|[^a-z])" + n.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "($|[^a-z])", "i");
      if (re.test(t)) return COUNTRY_NAMES[n];
    }
    return null;
  }

  // 国名だけの行か(住所の中の「France Street」などを国と取りちがえない)
  function countryExact(text) {
    const t = String(text || "").trim().toLowerCase();
    return COUNTRY_NAMES[t] || null;
  }

  // 国 → 使う関税表
  function tariffFor(iso) {
    if (!iso) return null;
    if (iso === "US") return "US";
    if (iso === "GB") return "UK";
    if (EU.has(iso)) return "EU";
    return "OTHER";
  }

  // 文字をそろえる(小文字・アクセント記号を外す・記号を空白に)
  function norm(s) {
    return String(s || "")
      .normalize("NFKD").replace(/[̀-ͯ]/g, "")
      .toLowerCase()
      .replace(/[^\p{L}\p{N}]+/gu, " ")
      .trim();
  }

  function hasWord(normTitle, kw, rawTitle) {
    // 文字のない言葉(例 1/8 のスケール)は、元のタイトルで前後が空白のときだけ当てる(f/1.8 に当てない)
    if (!/\p{L}/u.test(kw)) {
      if (rawTitle == null) return false;
      const re = new RegExp("(^|\\s)" + kw.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "(\\s|$)");
      return re.test(rawTitle);
    }
    const k = norm(kw);
    if (!k) return false;
    // 日本語など空白で区切らない言葉は、部分一致
    if (/[぀-ヿ一-鿿]/.test(k)) return normTitle.includes(k);
    return (" " + normTitle + " ").includes(" " + k + " ");
  }

  /** タイトル → 種類の候補(点数の高い順)。master = data/master.json の types */
  function classify(title, master) {
    const t = norm(title);
    const scored = [];
    for (const ty of master) {
      let score = 0; const hits = [];
      for (const lang of Object.keys(ty.keywords || {})) {
        for (const kw of ty.keywords[lang] || []) {
          if (hasWord(t, kw, title)) {
            const w = norm(kw).split(" ").length; // 2語以上の言葉は強い
            score += 1 + (w - 1) * 1.5; hits.push(kw);
          }
        }
      }
      for (const kw of ty.negative || []) if (hasWord(t, kw, title)) score -= 3;
      if (score > 0) scored.push({ id: ty.id, score, hits: [...new Set(hits)] });
    }
    scored.sort((a, b) => b.score - a.score);
    return scored.slice(0, 5);
  }

  // ICS2(EU)・CBP(米国)で、それだけでは受け付けられない言葉
  const VAGUE = ["parts", "part", "accessories", "accessory", "gift", "gifts", "sample", "samples",
    "equipment", "goods", "general goods", "stuff", "items", "item", "merchandise", "spare parts",
    "clothes", "clothing", "electronics", "toys", "toy", "collectibles", "personal effects", "used goods"];

  function isVague(name) {
    const n = norm(name).replace(/\bused\b/g, "").trim();
    if (!n) return true;
    if (VAGUE.includes(n)) return true;
    const words = n.split(" ");
    if (words.length < 2) return true; // 1語だけ(ブランド名や型番だけ)も不可
    // 一般語と型番(数字まじり)だけでできている名前も不可(例: "parts accessories" / "ABC-123 XYZ-456")
    const meaningful = words.filter(w => !VAGUE.includes(w) && !/\d/.test(w) && !["and", "for", "of", "with", "set", "lot"].includes(w));
    return meaningful.length === 0;
  }

  // タイトルから「ブランド+型番」らしい所を取り出す(英数字まじりの語=型番)
  const NOISE = new Set(("used tested working work works junk japan jdm from free shipping fs f s new " +
    "rare vintage good excellent mint condition boxed box w with without and for the of a an set lot " +
    "japanese genuine oem original official near read description no").split(" "));
  function brandModel(title) {
    const raw = String(title || "").replace(/[【】\[\]()（）]/g, " ").split(/\s+/).filter(Boolean);
    // 寸法・出力・ch数などは型番ではない(60mm / 4-Channel / 12V / 260km/h)
    const MEAS = /^\d+(\.\d+)?(mm|cm|m|ch|w|v|kg|g|inch|in|km\/h|mph|f|%|-channel|-ch|-way|-disc|-din|din|\/h)$/i;
    const idx = raw.findIndex(w => /[A-Za-z]/.test(w) && /\d/.test(w) && w.length >= 3 && !MEAS.test(w.replace(/[,.;:]+$/, "")));
    if (idx < 0) {
      // 型番がないときは、先頭の大文字だけの語(例: NISMO)をブランドとして使う
      const b = raw.find(w => /^[A-Z][A-Z&\-]{2,}$/.test(w) && !NOISE.has(w.toLowerCase()));
      return b || "";
    }
    const model = raw[idx].replace(/[,.;:]+$/, "");
    let brand = "";
    for (let i = idx - 1; i >= 0 && i >= idx - 2; i--) {
      const w = raw[i];
      if (/^[A-Za-z][A-Za-z&\-]+$/.test(w) && !NOISE.has(w.toLowerCase())) { brand = w; break; }
    }
    return (brand ? brand + " " : "") + model;
  }

  /** 告知用の商品名を作る(128字まで)。template 例: "Used digital camera, {brand_model}" */
  function declaredName(template, title, maxLen) {
    const bm = brandModel(title);
    let s = String(template || "");
    s = bm ? s.replace("{brand_model}", bm) : s.replace(/,?\s*\{brand_model\}/, "");
    s = s.replace(/\s+/g, " ").trim();
    const lim = maxLen || 128;
    return s.length > lim ? s.slice(0, lim).trim() : s;
  }

  /** 答え表の1件 + 地域 + (必要なら)選んだ選択肢 → コード */
  function codeFor(type, tariff, optionIndex) {
    if (!type || !type.variants || !type.variants.length) return null;
    const v = type.variants.length === 1 ? type.variants[0] : type.variants[optionIndex];
    if (!v) return null;
    if (tariff === "OTHER") return { code: v.hs6 || type.hs6, level: "HS6", desc_path: "国際共通(HS 6桁)", source: null };
    const c = v[tariff];
    return c ? { ...c, level: tariff } : null;
  }

  /** 質問に答えなくても進めるように、選択肢を自動で選ぶ。
   *  1) タイトルから分かる(hints) → 2) ふつうの答え(default_option)。why = "only" | "title" | "default" */
  function pickVariant(type, title) {
    const vs = (type && type.variants) || [];
    if (vs.length <= 1) return { index: 0, why: "only" };
    for (const h of type.hints || []) {
      let re; try { re = new RegExp(h.re, "iu"); } catch (e) { continue; }
      if (re.test(String(title || "")) && vs[h.option]) return { index: h.option, why: "title", label: h.label || "" };
    }
    const d = Number.isInteger(type.default_option) && vs[type.default_option] ? type.default_option : 0;
    return { index: d, why: "default" };
  }

  function formatUS(code) { // 8518402000 → 8518.40.20.00
    const d = String(code).replace(/\D/g, "");
    return d.length === 10 ? `${d.slice(0, 4)}.${d.slice(4, 6)}.${d.slice(6, 8)}.${d.slice(8)}` : d;
  }

  const api = { EU, countryToIso, countryExact, tariffFor, norm, classify, isVague, brandModel, declaredName, codeFor, pickVariant, formatUS };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.CPA_ENGINE = api;
})(typeof self !== "undefined" ? self : this);
