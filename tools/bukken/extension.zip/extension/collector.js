// 自動生成(tools/build_extension.sh)。元= static/collector.js
window.__bkCollector = function () {
  var TOOL = 'https://rental-space.net/tools/bukken/';
  var GAP = 2500;
  var MAXPAGE = 20;
  var SKIP_KEY = 'days-bulk-skip';
  if (!/(^|\.)athome\.co\.jp$/.test(location.hostname)) {
    alert('ここ(判定ツールのページ)ではなく、athomeのタブで押してください。「athomeで集める」で開いたathomeのタブに切り替えてから、もう一度このブックマークを押します');
    return;
  }
  if (window.__bkRun) {
    alert('実行中です。画面右下の表示を確認してください');
    return;
  }
  window.__bkRun = true;
  var stopped = false;
  var box = document.createElement('div');
  box.setAttribute('style', 'position:fixed;z-index:2147483647;right:16px;bottom:16px;width:380px;max-width:calc(100vw - 32px);max-height:calc(100vh - 32px);overflow:auto;background:#0F172A;color:#fff;border-radius:14px;padding:16px 18px;font:13px/1.6 -apple-system,BlinkMacSystemFont,sans-serif;box-shadow:0 10px 30px rgba(0,0,0,.35);text-align:left');
  document.body.appendChild(box);
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }
  function btn(id, label, main) {
    return '<button id="' + id + '" style="margin-top:10px;width:100%;padding:' + (main ? '11px' : '7px') + ';border:' + (main ? '0' : '1px solid rgba(255,255,255,.3)') + ';border-radius:10px;background:' + (main ? '#F97316' : 'transparent') + ';color:#fff;font-weight:' + (main ? '700' : '400') + ';font-size:' + (main ? '14px' : '12px') + ';cursor:pointer">' + label + '</button>';
  }
  function say(html, fin) {
    box.innerHTML = '<div style="font-weight:700;font-size:14px;margin-bottom:6px">物件の一括リサーチ</div>' + html + btn('bk-x', fin ? '閉じる' : '中止する', false);
    document.getElementById('bk-x').onclick = function () {
      stopped = true;
      box.remove();
      window.__bkRun = false;
    };
  }
  function sleep(ms) {
    return new Promise(function (r) { setTimeout(r, ms); });
  }
  function parts(v) {
    return String(v || '').split(/[,|]/).map(function (x) { return x.trim(); }).filter(Boolean);
  }
  function slim(b) {
    var t = b.tenpoPlus || {};
    var a = b.areaInfo || {};
    var i = b.bukkenInfo || {};
    var c = b.contract || {};
    return {
      id: b.id, prefCd: b.prefCd, title: b.title, location: b.location, tenant: b.tenant,
      traffic: (b.traffic || []).map(function (x) { return { l: x.lineName, s: x.stationName, w: x.tohoJikan }; }),
      contract: { price: c.price, managementFee: c.managementFee, deposit: c.deposit, keyMoney: c.keyMoney, guaranteeDeposit: c.guaranteeDeposit },
      info: { construction: i.construction, kaidateKai: i.kaidateKai, chikunengetsu: i.chikunengetsu },
      area: { area: a.area, tsubo: a.tsubo, unitPrice: a.unitPrice },
      tp: { inuki: t.isInuki, skel: t.isSkeleton, last: t.lastTenanto && t.lastTenanto.name, feat: (t.feature || []).map(function (f) { return f.name; }) },
      comment: b.recommendComment && b.recommendComment.comment,
      kaiin: b.kaiin && b.kaiin.syogo,
      dance: (b.tenpoSyuttenKano || []).some(function (g) {
        return (g.syogyosyu || []).some(function (s) { return s.code === 'tp129' && s.isCanOpenStore === '1'; });
      }) ? 1 : 0
    };
  }
  function toB64(bytes) {
    var s = '';
    for (var k = 0; k < bytes.length; k += 32768) {
      s += String.fromCharCode.apply(null, bytes.subarray(k, k + 32768));
    }
    return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }
  async function pack(obj) {
    var json = JSON.stringify(obj);
    if (window.CompressionStream) {
      var st = new Blob([json]).stream().pipeThrough(new CompressionStream('gzip'));
      var buf = await new Response(st).arrayBuffer();
      return 'z' + toB64(new Uint8Array(buf));
    }
    return 'j' + toB64(new TextEncoder().encode(json));
  }
  async function done(kind, payload, html) {
    var b = await pack(payload);
    var url = TOOL + '#' + kind + '=' + b;
    say(html + btn('bk-open', '判定ツールで開く', true), true);
    document.getElementById('bk-open').onclick = function () {
      window.open(url, '_blank', 'noopener');
    };
  }
  async function getJson(url) {
    var r = await fetch(url, { credentials: 'include' });
    var t = await r.text();
    if (t.trim().charAt(0) !== '{') {
      throw new Error('blocked');
    }
    return JSON.parse(t);
  }
  async function list(seo, roman, p) {
    var out = [];
    var count = 0;
    for (var pg = 1; pg <= MAXPAGE && !stopped; pg++) {
      var q = 'siteCd=00000&prefectureRoman=' + roman + '&seoNm=' + seo;
      Object.keys(p).forEach(function (k) {
        if (p[k]) {
          q += '&' + k + '=' + p[k];
        }
      });
      q += '&page=' + pg + '&num=50&sort_id=33&pageSetting=333000';
      var j = await getJson('/csite-bff/bukken/list/bukken?' + q);
      var bd = j.data && j.data.bukkenData;
      if (!bd) {
        break;
      }
      count = bd.bukkenCount || 0;
      (bd.bukkenList || []).forEach(function (b) { out.push(slim(b)); });
      var pe = document.getElementById('bk-pg');
      if (!pe) {
        pe = document.createElement('div');
        pe.id = 'bk-pg';
        pe.style.opacity = '.75';
        box.insertBefore(pe, document.getElementById('bk-x'));
      }
      pe.textContent = 'この条件: ' + out.length + ' / ' + count + '件' + (count > out.length ? '(残り約' + Math.ceil((count - out.length) / 50 * 3.5) + '秒)' : '');
      if (out.length >= count || !(bd.bukkenList || []).length) {
        break;
      }
      await sleep(GAP);
    }
    return { count: count, list: out };
  }
  var BASIC = ['PRICEFROM', 'PRICETO', 'TSUBO_TANKA_FROM', 'TSUBO_TANKA_TO', 'MENSEKI', 'TATEKOUZOU', 'EKITOHO', 'CHIKUNENSU', 'JOHOKOKAI', 'APPEAL'];
  function fromForm(o) {
    var basic = [];
    BASIC.forEach(function (k) { basic = basic.concat(parts(o[k])); });
    var gy = parts(o.DAIGYOSYU);
    if (String(o.ADD_NOTPP) === '1') {
      gy.push('tp999');
    }
    var eki = parts(o.EKI).filter(function (e) { return e.indexOf('_') > 0; }).map(function (e) { return e.replace('_', '/'); });
    return { basicConditions: basic.join(','), insistenceConditions: parts(o.KODAWARI).join(','), gyosyuConditions: gy.join(','), stationCds: eki.join(','), cityCds: parts(o.SHIKU).join(',') };
  }
  function pickConds(conds) {
    return new Promise(function (resolve) {
      var skip = [];
      try {
        skip = JSON.parse(localStorage.getItem(SKIP_KEY) || '[]');
      } catch (e) {
        skip = [];
      }
      var rows = conds.map(function (c, n) {
        var on = !c.ng && skip.indexOf(c.key) < 0 ? ' checked' : '';
        return '<label style="display:flex;gap:6px;align-items:flex-start;padding:5px 0;border-bottom:1px solid rgba(255,255,255,.12);cursor:pointer"><input type="checkbox" data-n="' + n + '"' + on + (c.ng ? ' disabled' : '') + ' style="margin-top:4px"><span>' + esc(c.label) + (c.ng ? '<br><span style="color:#FCA5A5">路線だけで絞った条件は未対応です(駅か市区町村で絞ってください)</span>' : '') + '</span></label>';
      }).join('');
      say('<div style="margin-bottom:6px">集める保存条件を選んでください(選び方はこのブラウザが覚えます)</div><div style="max-height:45vh;overflow:auto;margin-bottom:4px">' + rows + '</div>' + btn('bk-go', '集め始める', true));
      document.getElementById('bk-go').onclick = function () {
        var sel = [];
        var sk = [];
        box.querySelectorAll('input[data-n]').forEach(function (el) {
          var c = conds[Number(el.getAttribute('data-n'))];
          if (el.checked) {
            sel.push(c);
          } else {
            sk.push(c.key);
          }
        });
        try {
          localStorage.setItem(SKIP_KEY, JSON.stringify(sk));
        } catch (e) {
          sk = [];
        }
        resolve(sel);
      };
    });
  }
  async function saved() {
    var conds = [];
    var seen = {};
    document.querySelectorAll('a[data-trigger="cond_research"]').forEach(function (a) {
      var fn = a.getAttribute('data-form-name');
      var f = document.forms[fn];
      var m = (a.getAttribute('data-url') || '').match(/^\/([a-z_]+)\/([a-z]+)\/list\//);
      if (!f || !m || seen[fn] || !/^rent_(store|office)$/.test(m[1])) {
        return;
      }
      seen[fn] = 1;
      var o = {};
      new FormData(f).forEach(function (v, k) { o[k] = o[k] ? o[k] + ',' + v : v; });
      var tr = f.closest('tr');
      var jid = tr && tr.querySelector('[data-form-jokenid]');
      var area = tr && tr.cells && tr.cells[1] ? tr.cells[1].innerText.replace(/\s+/g, ' ').trim() : fn;
      var kd = parts(o.KODAWARI).map(function (k) { return { P01: '1階', P08: '地下階' }[k] || k; }).join('・');
      var p = fromForm(o);
      conds.push({ key: jid ? jid.getAttribute('data-form-jokenid') : fn, seo: m[1], roman: m[2], ken: o.KEN || '', label: area.slice(0, 70) + (kd ? ' / ' + kd : ''), p: p, ng: !p.stationCds && !p.cityCds && parts(o.ENSEN).length > 0 });
    });
    if (!conds.length) {
      say('保存した検索条件(貸店舗・貸事務所)が見つかりませんでした。athomeにログインしているか確認してください。', true);
      return;
    }
    var sel = await pickConds(conds);
    if (stopped) {
      return;
    }
    if (!sel.length) {
      say('条件がひとつも選ばれていません。', true);
      return;
    }
    var items = [];
    var meta = [];
    var blocked = false;
    for (var n = 0; n < sel.length && !stopped; n++) {
      var c = sel[n];
      say('条件 ' + (n + 1) + ' / ' + sel.length + ' を取得中…<br><span style="opacity:.75">' + esc(c.label.slice(0, 60)) + '</span><br>ここまで ' + items.length + '件');
      var r = null;
      try {
        r = await list(c.seo, c.roman, c.p);
      } catch (e) {
        blocked = true;
        break;
      }
      r.list.forEach(function (b) {
        b.c = c.key;
        items.push(b);
      });
      meta.push({ key: c.key, label: c.label, seo: c.seo, roman: c.roman, ken: c.ken, count: r.count, got: r.list.length });
      if (n < sel.length - 1) {
        await sleep(GAP);
      }
    }
    if (stopped) {
      return;
    }
    var warn = blocked ? '<div style="color:#FCA5A5;margin-bottom:6px">athomeの制限にかかったので、' + meta.length + '条件目までで止めました。集めた分だけ開けます。残りは30分ほど待ってから、もう一度押してください。</div>' : '';
    await done('bulk', { v: 1, at: Date.now(), source: 'saved', conds: meta, items: items, partial: blocked ? 1 : 0 }, warn + meta.length + '条件・' + items.length + '件を集めました。');
  }
  async function current() {
    var m = location.pathname.match(/^\/([a-z_]+)\/([a-z]+)\/list\//);
    if (!m) {
      say('検索結果ページのURLを読み取れませんでした。「保存した検索条件」ページで押してください。', true);
      return;
    }
    var s = new URLSearchParams(location.search);
    var st = [];
    parts(s.get('stations')).forEach(function (g) {
      var a = g.split('-');
      var lc = a[0].split('_')[1] || '';
      (a[1] || '').split('_').forEach(function (x) {
        if (x && lc) {
          st.push(lc + '/' + x);
        }
      });
    });
    var p = { basicConditions: s.get('basic') || '', insistenceConditions: s.get('kod') || '', gyosyuConditions: s.get('ind') || '', stationCds: st.join(','), cityCds: s.get('cityCds') || '' };
    say('この検索結果を取得中…');
    var r = null;
    try {
      r = await list(m[1], m[2], p);
    } catch (e) {
      say('<div style="color:#FCA5A5">athomeの制限にかかりました。30分ほど待ってから、もう一度押してください。</div>', true);
      return;
    }
    if (stopped) {
      return;
    }
    var label = (document.title || '').replace(/【アットホーム】/, '').slice(0, 70);
    r.list.forEach(function (b) { b.c = 'list'; });
    await done('bulk', { v: 1, at: Date.now(), source: 'list', conds: [{ key: 'list', label: label, seo: m[1], roman: m[2], ken: s.get('pref') || '', count: r.count, got: r.list.length }], items: r.list, partial: 0 }, r.list.length + '件を集めました。');
  }
  function capDoc(doc, url) {
    var pairs = {};
    doc.querySelectorAll('tr').forEach(function (tr) {
      var cells = Array.prototype.filter.call(tr.children, function (c) { return /^(TH|TD)$/.test(c.tagName); });
      for (var k = 0; k < cells.length - 1; k++) {
        if (cells[k].tagName === 'TH' && cells[k + 1].tagName === 'TD') {
          var key = cells[k].textContent.replace(/\s+/g, '');
          var val = cells[k + 1].textContent.replace(/\s+/g, ' ').trim();
          if (key && val && !(key in pairs)) {
            pairs[key] = val;
          }
          k++;
        }
      }
    });
    var th = Array.prototype.find.call(doc.querySelectorAll('th'), function (el) { return el.textContent.indexOf('交通') >= 0; });
    var traffic = '';
    if (th && th.nextElementSibling) {
      var ps = th.nextElementSibling.querySelectorAll('p, li, div');
      traffic = ps.length ? Array.prototype.map.call(ps, function (x) { return x.textContent; }).join('\n') : th.nextElementSibling.textContent;
    }
    var dt = Array.prototype.find.call(doc.querySelectorAll('dt'), function (el) { return el.textContent.indexOf('ポイント') >= 0; });
    var point = dt && dt.nextElementSibling ? dt.nextElementSibling.textContent.replace(/\s+/g, ' ').trim() : '';
    var cm = doc.querySelector('.shop-comment__comment');
    var h1 = doc.querySelector('h1');
    return { source: 'athome', url: url, title: (h1 ? h1.textContent : doc.title || '').trim(), pairs: pairs, trafficText: traffic, pointText: point, comment: cm ? cm.textContent.trim() : null };
  }
  async function detail(ids) {
    var items = [];
    var blocked = false;
    for (var n = 0; n < ids.length && !stopped; n++) {
      var a = ids[n].split(':');
      var seo = a.length > 1 ? a[0] : 'rent_store';
      var id = a[a.length - 1];
      if (!/^[a-z_]+$/.test(seo) || !/^\d+$/.test(id)) {
        continue;
      }
      say('物件の詳細ページを確認中… ' + (n + 1) + ' / ' + ids.length + '<br><span style="opacity:.75">athomeに負荷をかけないよう2.5秒おきに開いています</span>');
      var path = '/' + seo + '/' + id + '/';
      var r = await fetch(path, { credentials: 'include' });
      var t = r.status === 404 ? '' : await r.text();
      if (r.status === 404 || /掲載.{0,8}終了|お探しの物件/.test(t.slice(0, 30000)) && t.indexOf('賃料') < 0) {
        items.push({ id: id, ended: 1 });
      } else if (/please_wait/.test(r.url) || t.indexOf('<table') < 0) {
        blocked = true;
        break;
      } else {
        items.push({ id: id, cap: capDoc(new DOMParser().parseFromString(t, 'text/html'), location.origin + path) });
      }
      if (n < ids.length - 1) {
        await sleep(GAP);
      }
    }
    if (stopped) {
      return;
    }
    var warn = blocked ? '<div style="color:#FCA5A5;margin-bottom:6px">athomeの制限にかかったので、' + items.length + '件までで止めました。</div>' : '';
    await done('bulkdetail', { v: 1, at: Date.now(), items: items }, warn + items.length + '件の詳細ページを確認しました。');
  }
  function fromB64(s) {
    var b = atob(s.replace(/-/g, '+').replace(/_/g, '/') + '==='.slice(0, (4 - s.length % 4) % 4));
    var bytes = new Uint8Array(b.length);
    for (var i = 0; i < b.length; i++) {
      bytes[i] = b.charCodeAt(i);
    }
    return new TextDecoder().decode(bytes);
  }
  async function plan(pl) {
    var conds = pl && pl.conds ? pl.conds : [];
    if (!conds.length) {
      say('条件が入っていません。判定ツールの「条件づくり」から「athomeで集める」を押して開き直してください。', true);
      return;
    }
    var items = [];
    var meta = [];
    var blocked = false;
    for (var n = 0; n < conds.length && !stopped; n++) {
      var c = conds[n];
      say('検索 ' + (n + 1) + ' / ' + conds.length + ' を取得中…<br><span style="opacity:.75">' + esc(c.label) + '</span><br>ここまで ' + items.length + '件');
      var r = null;
      try {
        r = await list(c.seo || 'rent_store', c.roman, c.p || {});
      } catch (e) {
        blocked = true;
        break;
      }
      r.list.forEach(function (b) {
        b.c = c.key;
        items.push(b);
      });
      meta.push({ key: c.key, label: c.label, seo: c.seo || 'rent_store', roman: c.roman, ken: c.ken, count: r.count, got: r.list.length, stations: c.stations || [] });
      if (n < conds.length - 1) {
        await sleep(GAP);
      }
    }
    if (stopped) {
      return;
    }
    var warn = blocked ? '<div style="color:#FCA5A5;margin-bottom:6px">athomeの制限にかかったので、' + meta.length + '検索目までで止めました。集めた分だけ開けます。残りは30分ほど待ってから、判定ツールから開き直してください。</div>' : '';
    await done('bulk', { v: 1, at: Date.now(), source: 'plan', plan: pl.name || '', desc: pl.desc || '', conds: meta, items: items, partial: blocked ? 1 : 0 }, warn + '「' + esc(pl.name || '条件') + '」' + meta.length + '検索・' + items.length + '件を集めました。');
  }
  var INQ_KEY = 'bk-inq';
  function setChecked(el, on) {
    if (!el) {
      return;
    }
    if (!!el.checked !== !!on) {
      el.click();
    }
    if (!!el.checked !== !!on) {
      el.checked = !!on;
      el.dispatchEvent(new Event('change', { bubbles: true }));
    }
  }
  function setVal(el, v) {
    if (!el) {
      return false;
    }
    el.value = v;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    return true;
  }
  function inqOpen(pl) {
    var ids = (pl.items || []).map(function (it) { return String(it.id); }).filter(function (x) { return /^\d+$/.test(x); });
    if (!ids.length) {
      say('問い合わせる物件が入っていません。判定ツールの「一括リサーチ」で物件を選んでから開き直してください。', true);
      return;
    }
    try {
      sessionStorage.setItem(INQ_KEY, JSON.stringify(pl));
    } catch (e) {
      say('<div style="color:#FCA5A5">ブラウザに一時保存できませんでした(プライベートモード?)。</div>', true);
      return;
    }
    say('athomeの「まとめてメール問い合わせ」入力画面を開きます… ' + ids.length + '件');
    var f = document.createElement('form');
    f.method = 'post';
    f.action = '/inquiry/bukken/input/rent-biz/';
    var add = function (k, v) {
      var i = document.createElement('input');
      i.type = 'hidden';
      i.name = k;
      i.value = v;
      f.appendChild(i);
    };
    var rb = document.querySelector('input[name="RBUID"]');
    add('SITECD', '00000');
    add('BKLISTID', '001LPC');
    add('ITEM', 'jr');
    add('ART', '03');
    add('SEARCHDIV', '1');
    if (rb && rb.value) {
      add('RBUID', rb.value);
    }
    add('BUKKEN_ART', ids.map(function (x) { return x + '_03'; }).join(','));
    add('DOWN', '1');
    add('isTradeAreaInquiry', 'false');
    add('newListingFlg', 'false');
    document.body.appendChild(f);
    window.__bkRun = false;
    f.submit();
  }
  function inqApply(pl) {
    var q = function (sel) { return document.querySelector(sel); };
    var pr = pl.profile || {};
    var cb = function (n) { return q('input#' + n) || q('input[name="' + n + '"]'); };
    ['C1', 'C2', 'C3', 'C4', 'C5', 'C6'].forEach(function (n) { setChecked(cb(n), true); });
    var labelOf = function (el) { var t = (el.labels && el.labels[0] ? el.labels[0].textContent : '') + ' ' + ((el.closest('label') || el.parentElement || {}).textContent || ''); return t; };
    var reason = q('input[name="inquiryReason"][value="01"]') || Array.prototype.find.call(document.querySelectorAll('input[type="radio"]'), function (el) { return /開店|開業/.test(labelOf(el)); });
    if (reason) {
      reason.click();
      if (!reason.checked) {
        reason.checked = true;
        reason.dispatchEvent(new Event('change', { bubbles: true }));
      }
    }
    var nk = q('select[name="nkyojik"]') || Array.prototype.find.call(document.querySelectorAll('select'), function (el) { return Array.prototype.some.call(el.options, function (o) { return /希望物件があり次第/.test(o.textContent); }); });
    if (nk) {
      var opt = Array.prototype.find.call(nk.options, function (o) { return /希望物件があり次第/.test(o.textContent); });
      if (opt) {
        nk.value = opt.value;
        nk.dispatchEvent(new Event('change', { bubbles: true }));
      }
    }
    setVal(q('textarea[name="desired_industry"]'), pl.industry || '');
    setVal(q('input[name="company_name"]'), pr.company || '');
    setVal(q('input[name="full_name"]'), pr.name || '');
    setVal(q('input[name="mail"]'), pr.email || '');
    setVal(q('input[name="tel"]'), String(pr.tel || '').replace(/[^\d]/g, ''));
    setVal(q('textarea[name="bikou"]'), pl.msg || '');
    setChecked(q('input[name="crm_info_accept_flg"]'), false);
    setChecked(q('input[name="crm_info_hankyo_flg"]'), false);
    setChecked(q('input[name="allBukChk"]'), false);
    document.querySelectorAll('input[name="RECENT_BUKKEN[]"]').forEach(function (el) { setChecked(el, false); });
    document.querySelectorAll('input[name="list[]"]').forEach(function (el) { setChecked(el, false); });
    document.querySelectorAll('input[name="all_ck_all"]').forEach(function (el) { setChecked(el, false); });
    var listEls = pl.items || [];
  }
  function inqFill(pl) {
    var q = function (sel) { return document.querySelector(sel); };
    inqApply(pl);
    setTimeout(function () { inqApply(pl); }, 1200);
    setTimeout(function () { inqApply(pl); inqReport(pl); }, 3000);
    var ta = q('textarea[name="bikou"]');
    if (ta) {
      ta.scrollIntoView({ block: 'center' });
    }
    inqReport(pl);
  }
  function inqReport(pl) {
    var q = function (sel) { return document.querySelector(sel); };
    var listEls = pl.items || [];
    var cnt = function (sel) { return document.querySelectorAll(sel).length; };
    var left = document.querySelectorAll('input[name="list[]"]:checked, input[name="RECENT_BUKKEN[]"]:checked').length;
    say('<div style="margin-bottom:6px">入力を済ませました(' + listEls.length + '件・氏名/メール/電話/文面) <span style="opacity:.6">v1.3・内容' + cnt('#C1:checked,#C2:checked,#C3:checked,#C4:checked,#C5:checked,#C6:checked') + '/6・一緒に' + cnt('input[name="list[]"]:checked') + '/' + cnt('input[name="list[]"]') + '・まとめて' + cnt('input[name="RECENT_BUKKEN[]"]:checked') + '・理由' + (document.querySelector('input[type="radio"]:checked') ? 'OK' : '未') + '・時期' + (function () { var e = q('select[name="nkyojik"]'); return e && e.selectedIndex > 0 ? 'OK' : '未'; })() + '</span></div>' + (left ? '<div style="color:#FCA5A5;margin-bottom:6px">※外せなかったチェックが' + left + '個あります。「こちらの物件も一緒に」「まとめてお問合せ」の欄は全部外してください(余計な物件に送らないため)</div>' : '') + '<ol style="margin:0;padding-left:18px;line-height:1.7"><li>上の「お問合せの物件」が選んだ物件か確認。「こちらの物件も一緒に」と「まとめてお問合せ」のチェックは外してあります(入れると余計な物件にも送られます)</li><li>一番下の<b>「内容確認へ進む」</b>→ 確認画面で<b>「送信」</b></li><li>届いた<b>SMSの認証番号</b>を入力して完了(ここは必ずご自身で)</li></ol><div style="opacity:.75;margin-top:6px">完了画面で「判定ツールに記録」を押すと、対応状況が「問い合わせ済」になります</div>', true);
  }
  function inqDone(pl) {
    var ids = (pl.items || []).map(function (it) { return String(it.id); });
    var b = btoa(encodeURIComponent(ids.join(','))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    say('お問い合わせが完了しました(' + ids.length + '件)。' + btn('bk-open', '判定ツールに「問い合わせ済」を記録する', true), true);
    document.getElementById('bk-open').onclick = function () {
      try {
        sessionStorage.removeItem(INQ_KEY);
      } catch (e) {
        ids = ids;
      }
      window.open(TOOL + '#bkinqdone=' + b, '_blank', 'noopener');
    };
  }
  function inqStage() {
    var pl = null;
    try {
      pl = JSON.parse(sessionStorage.getItem(INQ_KEY) || 'null');
    } catch (e) {
      pl = null;
    }
    if (!pl || !/^\/inquiry\/bukken\//.test(location.pathname)) {
      return false;
    }
    var t = document.title || '';
    if (/\/input\//.test(location.pathname)) {
      inqFill(pl);
    } else if (/完了/.test(t) || /complete|finish|thanks/.test(location.pathname)) {
      inqDone(pl);
    } else {
      say('内容を確認して<b>「送信」</b>を押し、届いたSMSの認証番号を入力してください(ここはご自身で)。', true);
    }
    return true;
  }
  function fail(e) {
    say('<div style="color:#FCA5A5">エラーが起きました: ' + esc(e && e.message ? e.message : e) + '</div>', true);
  }
  var hm = location.hash.match(/bkcheck=([^&]+)/);
  var pm = location.hash.match(/bkplan=([A-Za-z0-9_-]+)/);
  var qm = location.hash.match(/bkinq=([A-Za-z0-9_-]+)/);
  if (qm) {
    Promise.resolve().then(function () {
      return inqOpen(JSON.parse(fromB64(qm[1])));
    }).catch(fail);
  } else if (inqStage()) {
    window.__bkRun = false;
  } else if (hm) {
    detail(decodeURIComponent(hm[1]).split(',')).catch(fail);
  } else if (pm) {
    Promise.resolve().then(function () {
      return plan(JSON.parse(fromB64(pm[1])));
    }).catch(fail);
  } else if (/^\/personal\/condition\//.test(location.pathname)) {
    saved().catch(fail);
  } else if (/\/list\//.test(location.pathname)) {
    current().catch(fail);
  } else {
    say('athomeの「保存した検索条件」ページか、検索結果ページで押してください。<br><a href="/personal/condition/" style="color:#FDBA74">保存した検索条件を開く</a>', true);
  }
};
