// athomeのページで動く。#bkplan=(条件づくりから開いたページ)や #bkcheck=(詳細ページ確認)が付いていれば自動で集め始める。付いていなければ右下に小さなボタンを出す(保存した検索条件・検索結果ページ用)
(function () {
  function run() { if (window.__bkCollector) window.__bkCollector(); }
  var inq = false;
  try { inq = !!sessionStorage.getItem('bk-inq') && /^\/inquiry\/bukken\//.test(location.pathname); } catch (e) { inq = false; }
  if (/#(bkplan|bkcheck|bkinq)=/.test(location.hash) || inq) { setTimeout(run, 800); return; }
  var b = document.createElement('button');
  b.textContent = '一括リサーチ(判定ツール)';
  b.setAttribute('style', 'position:fixed;z-index:2147483646;right:16px;bottom:16px;padding:10px 16px;border:0;border-radius:999px;background:#0F172A;color:#fff;font:700 13px -apple-system,BlinkMacSystemFont,sans-serif;box-shadow:0 6px 18px rgba(0,0,0,.3);cursor:pointer');
  b.onclick = function () { b.remove(); run(); };
  document.body.appendChild(b);
})();
