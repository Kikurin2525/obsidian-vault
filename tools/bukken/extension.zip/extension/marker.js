// 判定ツールのページに「拡張が入っている」印を付ける(条件づくりの案内文が短くなる)
document.documentElement.dataset.bkExt = '1';
